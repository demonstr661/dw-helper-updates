chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'PLAY_AUDIO') {
        const audio = new Audio("alarm.mp3");
        audio.play().catch(e => console.error('Audio play error:', e));
    }
});

window.addEventListener('load', () => {
    console.log('Offscreen document ready');
});
