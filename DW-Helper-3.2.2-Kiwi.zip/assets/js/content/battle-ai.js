(function initBattleAI(global) {
  if (global.DWBattleAI) return;
  const ATTACK_ZONES = { '1': 'head', '2': 'chest', '3': 'groin', '4': 'legs' };
  const DEFENCE_ZONES = {
    '1': ['head', 'chest'], '2': ['chest', 'groin'],
    '3': ['groin', 'legs'], '4': ['head', 'legs']
  };
  const ZONE_NAMES = {
    head: /голов/i, chest: /груд/i, groin: /пах/i, legs: /ног/i
  };
  const clampMemory = memory => {
    const entries = Object.entries(memory || {}).sort((a, b) => (b[1].updatedAt || 0) - (a[1].updatedAt || 0));
    return Object.fromEntries(entries.slice(0, 100));
  };
  const blankEntry = () => ({ attacks: {}, defences: {}, skills: {}, samples: 0, updatedAt: Date.now(), seen: {} });
  const bump = (bucket, key, name = '') => {
    if (!bucket[key]) bucket[key] = { count: 0, lastSeen: 0, name };
    bucket[key].count += 1;
    bucket[key].lastSeen = Date.now();
    if (name) bucket[key].name = name;
  };
  const weight = record => {
    if (!record) return 0;
    const ageDays = Math.max(0, Date.now() - (record.lastSeen || 0)) / 86_400_000;
    return (Number(record.count) || 0) * Math.exp(-ageDays / 30);
  };
  const opponentIdentity = () => {
    const links = [...document.querySelectorAll('a[href*="user.php?id="]')]
      .filter(link => (link.textContent || '').trim());
    const link = links.at(-1);
    if (!link) return { key: 'unknown-opponent', name: 'Противник' };
    const name = link.textContent.trim().replace(/\s+/g, ' ').slice(0, 120);
    let id = '';
    try { id = new URL(link.href).searchParams.get('id') || ''; } catch (_) {}
    return { key: id ? `user:${id}` : `name:${name.toLowerCase()}`, name };
  };
  const zoneFromText = text => Object.keys(ZONE_NAMES).find(zone => ZONE_NAMES[zone].test(text)) || null;

  function observe(entry) {
    const opponent = opponentIdentity();
    const bodyText = (document.body?.textContent || '').replace(/\s+/g, ' ');
    const relevant = bodyText.split(/(?<=[.!?])\s+/).filter(part =>
      opponent.name !== 'Противник' && part.toLowerCase().includes(opponent.name.toLowerCase()) || /противник|враг|оппонент/i.test(part)
    );
    const chunks = relevant.length ? relevant : [];
    for (const chunk of chunks) {
      const zone = zoneFromText(chunk);
      if (!zone) continue;
      if (/защищ|блок|защита/i.test(chunk)) bump(entry.defences, zone);
      else if (/удар|атак|бьёт|бьет/i.test(chunk)) bump(entry.attacks, zone);
    }
    const skillList = Object.values(state.skills || {});
    for (const chunk of chunks) {
      for (const skill of skillList) {
        if (skill.name && chunk.toLowerCase().includes(String(skill.name).toLowerCase())) {
          bump(entry.skills, String(skill.id), String(skill.name));
        }
      }
    }
    if (chunks.length) entry.samples += 1;
    entry.updatedAt = Date.now();
    return opponent;
  }

  function choose(entry, currentAttack, currentDefence) {
    if (!entry || entry.samples < 2) {
      return { attack: currentAttack, defence: currentDefence, confidence: 'low', reason: 'Недостаточно наблюдений: сохранена базовая тактика.' };
    }
    const defenceScores = Object.entries(ATTACK_ZONES).map(([zone, name]) => ({
      zone, score: weight(entry.defences?.[name])
    }));
    const attack = defenceScores.some(item => item.score > 0)
      ? defenceScores.sort((a, b) => a.score - b.score)[0].zone
      : currentAttack;
    const attackWeights = Object.entries(entry.attacks || {}).map(([zone, record]) => ({ zone, score: weight(record) }));
    const defence = Object.entries(DEFENCE_ZONES).map(([choice, covered]) => ({
      choice,
      score: attackWeights.reduce((sum, item) => sum + (covered.includes(item.zone) ? item.score : 0), 0)
    })).sort((a, b) => b.score - a.score)[0];
    return {
      attack,
      defence: defence?.score > 0 ? defence.choice : currentDefence,
      confidence: entry.samples >= 6 ? 'high' : 'medium',
      reason: `Атака в наименее защищаемую зону; защита по частоте ударов (${entry.samples} набл.).`
    };
  }

  function setFormChoice(form, name, value) {
    if (!value) return;
    const select = form.querySelector(`select[name="${name}"]`);
    if (select && [...select.options].some(option => option.value === String(value))) {
      select.value = String(value);
      return;
    }
    const input = [...form.querySelectorAll(`input[name="${name}"]`)].find(element => element.value === String(value));
    if (input) input.checked = true;
  }

  function adaptSkills(form, availableSkills, entry, decision) {
    const safe = (availableSkills || []).filter(skill => {
      const input = [...form.querySelectorAll('input[name="skills[]"]')].find(element => element.value === String(skill.id));
      return input?.checked;
    });
    if (!safe.length || !entry || entry.samples < 2) return [];
    const attackMemory = Object.values(entry.attacks || {}).some(weight);
    const defenceMemory = Object.values(entry.defences || {}).some(weight);
    const scored = safe.map(skill => {
      const name = String(skill.name || '').toLowerCase();
      let score = 0;
      if (attackMemory && /защит|кожа|блок|уклон|барьер/.test(name)) score += 3;
      if (defenceMemory && /удар|атак|стрел|клин|огон|молн|маг/.test(name)) score += 3;
      if (entry.skills?.[String(skill.id)]) score += 2;
      if (decision.confidence === 'high') score += 0.5;
      return { skill, score };
    }).sort((a, b) => b.score - a.score);
    const meaningful = scored.filter(item => item.score > 0);
    const selected = (meaningful.length ? meaningful : scored.slice(0, 1)).slice(0, 2);
    const selectedIds = new Set(selected.map(item => String(item.skill.id)));
    for (const skill of availableSkills || []) {
      const input = [...form.querySelectorAll('input[name="skills[]"]')].find(element => element.value === String(skill.id));
      if (input) input.checked = selectedIds.has(String(skill.id));
    }
    return [...selectedIds];
  }

  async function persist(memory, opponent, decision, skillIds) {
    const battleAI = {
      ...state.battleAI,
      memory: clampMemory(memory),
      lastDecision: {
        opponent: opponent.name, attack: decision.attack, defence: decision.defence,
        confidence: decision.confidence, reason: decision.reason,
        skillIds: skillIds || [], updatedAt: Date.now(), mode: state.battleAI.mode
      }
    };
    Object.assign(state, { battleAI });
    await updateState({ battleAI });
  }

  const fighterIdentities = () => {
    const fighters = [];
    const known = new Set();
    for (const link of document.querySelectorAll('a[href*="user.php?id="]')) {
      const name = (link.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 120);
      if (!name) continue;
      let id = '';
      try { id = new URL(link.href, location.href).searchParams.get('id') || ''; } catch (_) {}
      const key = id ? `user:${id}` : `name:${name.toLowerCase()}`;
      if (known.has(key)) continue;
      known.add(key);
      fighters.push({ key, name });
    }
    return fighters;
  };

  const isColosseumPage = () => {
    if (/colosseum|колизе/i.test(location.href)) return true;
    const text = (document.body?.textContent || '').slice(0, 12000);
    return /колизе/i.test(text) && /бой|битва|сражен/i.test(text);
  };

  const colosseumBattleId = () => {
    try {
      const current = new URL(location.href);
      const id = ['battle_id', 'battle', 'id', 'log'].map(key => current.searchParams.get(key)).find(Boolean) || 'current';
      return `${current.pathname}:${id}`.slice(0, 160);
    } catch (_) {
      return 'colosseum:current';
    }
  };

  const eventHash = text => {
    let hash = 2166136261;
    for (let index = 0; index < text.length; index++) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(36);
  };

  const pruneSeen = seen => Object.fromEntries(Object.entries(seen || {})
    .sort((left, right) => right[1] - left[1]).slice(0, 100));

  async function observeColosseum() {
    if (!state.battleAI?.learnColosseum || !isColosseumPage()) return { observed: 0, fighters: [] };
    const fighters = fighterIdentities();
    if (!fighters.length) return { observed: 0, fighters: [] };
    const logRoots = [...document.querySelectorAll('.dw-bt__log, .battle-log, #battle-log, #log')];
    const sourceText = (logRoots.length ? logRoots.map(root => root.innerText || root.textContent).join('\n') : document.body?.innerText || document.body?.textContent || '')
      .replace(/\r/g, '');
    const chunks = sourceText.split(/\n+|(?<=[.!?])\s+/).map(part => part.replace(/\s+/g, ' ').trim()).filter(Boolean);
    const battleId = colosseumBattleId();
    const memory = { ...(state.battleAI.memory || {}) };
    const observedFighters = new Set();
    let observed = 0;

    for (const chunk of chunks) {
      const kind = /защищ|блок|защита/i.test(chunk) ? 'defences'
        : /удар|атак|бьёт|бьет/i.test(chunk) ? 'attacks' : null;
      if (!kind) continue;
      const zones = Object.keys(ZONE_NAMES).filter(zone => ZONE_NAMES[zone].test(chunk));
      if (!zones.length) continue;
      const lowerChunk = chunk.toLowerCase();
      const actor = fighters.map(fighter => ({ fighter, at: lowerChunk.indexOf(fighter.name.toLowerCase()) }))
        .filter(item => item.at >= 0).sort((left, right) => left.at - right.at)[0]?.fighter;
      if (!actor) continue;
      const previous = memory[actor.key] || blankEntry();
      const signature = `${battleId}:${actor.key}:${eventHash(`${kind}:${zones.join(',')}:${chunk}`)}`;
      if (previous.seen?.[signature]) continue;
      const entry = {
        ...previous,
        attacks: { ...(previous.attacks || {}) }, defences: { ...(previous.defences || {}) },
        skills: { ...(previous.skills || {}) }, seen: { ...(previous.seen || {}) }
      };
      entry.seen[signature] = Date.now();
      for (const zone of zones) bump(entry[kind], zone);
      for (const skill of Object.values(state.skills || {})) {
        if (skill.name && lowerChunk.includes(String(skill.name).toLowerCase())) {
          bump(entry.skills, String(skill.id), String(skill.name));
        }
      }
      entry.samples = (Number(entry.samples) || 0) + 1;
      entry.updatedAt = Date.now();
      entry.name = actor.name;
      entry.source = 'colosseum';
      entry.seen = pruneSeen(entry.seen);
      memory[actor.key] = entry;
      observedFighters.add(actor.name);
      observed += 1;
    }

    if (!observed) return { observed: 0, fighters: [] };
    const battleAI = {
      ...state.battleAI,
      memory: clampMemory(memory),
      lastObservation: {
        battle: battleId, fighters: [...observedFighters], samples: observed, updatedAt: Date.now()
      }
    };
    Object.assign(state, { battleAI });
    await updateState({ battleAI });
    return { observed, fighters: [...observedFighters] };
  }

  function startColosseumObserver() {
    if (global.DWBattleAIObserver) return;
    let observer = null;
    let timer = null;
    let scanning = false;
    let queued = false;
    const controller = { disconnect() { observer?.disconnect(); clearTimeout(timer); } };
    global.DWBattleAIObserver = controller;
    const scan = async () => {
      clearTimeout(timer);
      timer = null;
      if (scanning) { queued = true; return; }
      scanning = true;
      try { await observeColosseum(); } catch (_) {}
      finally {
        scanning = false;
        if (queued) { queued = false; schedule(); }
      }
    };
    const schedule = () => {
      clearTimeout(timer);
      timer = setTimeout(scan, 180);
    };
    const ready = typeof global.waitToReadyState === 'function' ? global.waitToReadyState() : Promise.resolve();
    Promise.resolve(ready).then(() => {
      if (!state.battleAI?.learnColosseum || !isColosseumPage()) return;
      scan();
      if (typeof MutationObserver === 'function' && document.body) {
        observer = new MutationObserver(schedule);
        observer.observe(document.body, { childList: true, subtree: true, characterData: true });
        window.addEventListener('pagehide', () => controller.disconnect(), { once: true });
      }
    }).catch(() => {});
  }

  global.DWBattleAI = {
    choose,
    observeColosseum,
    startColosseumObserver,
    async beforeSubmit(form, { availableSkills = [] } = {}) {
      if (!form || !state.battleAI || form.dataset.dwAiObserved) return;
      form.dataset.dwAiObserved = '1';
      const memory = { ...(state.battleAI.memory || {}) };
      const probe = blankEntry();
      const opponent = observe(probe);
      const previous = memory[opponent.key] || blankEntry();
      const entry = {
        attacks: { ...previous.attacks }, defences: { ...previous.defences },
        skills: { ...previous.skills }, samples: previous.samples, updatedAt: previous.updatedAt,
        seen: { ...(previous.seen || {}) }, name: previous.name || opponent.name, source: previous.source || 'battle'
      };
      for (const kind of ['attacks', 'defences', 'skills']) {
        for (const [key, record] of Object.entries(probe[kind])) {
          entry[kind][key] = {
            count: (entry[kind][key]?.count || 0) + record.count,
            lastSeen: record.lastSeen, name: record.name || entry[kind][key]?.name || ''
          };
        }
      }
      entry.samples += probe.samples;
      entry.updatedAt = Date.now();
      memory[opponent.key] = entry;
      const decision = choose(entry, state.battles.attack, state.battles.defence);
      let skillIds = [];
      if (state.battleAI.mode === 'auto') {
        setFormChoice(form, 'attack', decision.attack);
        setFormChoice(form, 'defence', decision.defence);
        if (state.battleAI.autoSkills) skillIds = adaptSkills(form, availableSkills, entry, decision);
      }
      await persist(memory, opponent, decision, skillIds);
    }
  };
  startColosseumObserver();
})(globalThis);
