// Локальное чтение уже загруженных страниц. В этом модуле нет сетевых запросов.
var DWOfflineScanner = (() => {
  'use strict';

  const clean = value => String(value ?? '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();

  function toDocument(input) {
    if (!input) return null;
    if (input.nodeType === 9) return input;
    if (input.nodeType === 1) return input.ownerDocument;
    if (typeof input === 'string') return new DOMParser().parseFromString(input, 'text/html');
    return null;
  }

  function pageUrl(doc) {
    try {
      const href = doc.location?.href || doc.URL || '';
      const parsed = new URL(href);
      return ['http:', 'https:'].includes(parsed.protocol) ? parsed : null;
    } catch (_) {
      return null;
    }
  }

  function parameter(href, name) {
    try {
      return new URL(href, 'https://dreamwar.ru/').searchParams.get(name);
    } catch (_) {
      return null;
    }
  }

  function links(doc, selector) {
    return [...doc.querySelectorAll(selector)];
  }

  function unique(items, key = item => item.id) {
    const seen = new Set();
    return items.filter(item => {
      const id = key(item);
      if (!id || seen.has(id)) return false;
      seen.add(id);
      return true;
    });
  }

  function cleanNick(value) {
    let nick = clean(value)
      .replace(/\s*[·|]\s*\d+\s*(?:ур\.|уровень).*$/i, '')
      .replace(/\s*\[\d+\]\s*$/, '')
      .replace(/\s*-\s*Dreamwar.*$/i, '')
      .trim();
    if (!nick || nick.length > 40 || /^(?:персонаж|профиль|информация|dreamwar(?:\.ru)?)$/i.test(nick)) return null;
    return nick;
  }

  function findNick(doc) {
    const selectors = [
      '[data-user-nick]', '[data-nick]', '.dw-user__name', '.dw-user__nick',
      '.dw-profile__name', '.dw-profile__nick', '.dw-uinfo__name', '.dw-uinfo__title',
      '.dw-header__nick', '.dw-header__name', '.user-name', '.user-nick',
      '.nickname', '#nickname', '.dw-usr__name', '.dw-u__nick'
    ];
    for (const selector of selectors) {
      for (const element of doc.querySelectorAll(selector)) {
        const nick = cleanNick(element.getAttribute('data-user-nick') || element.getAttribute('data-nick') || element.textContent);
        if (nick) return nick;
      }
    }
    for (const anchor of links(doc, 'a[href*="user.php"]')) {
      if (parameter(anchor.href, 'id')) continue;
      const nick = cleanNick(anchor.textContent);
      if (nick) return nick;
    }
    const body = clean(doc.body?.textContent);
    const labelled = body.match(/(?:Ник|Имя персонажа|Персонаж)\s*:\s*([^\s][^|·]{0,38}?)(?=\s+(?:Уровень|Сторона|Сейчас в|Клан|Очки)\b|$)/i);
    if (labelled) {
      const nick = cleanNick(labelled[1]);
      if (nick) return nick;
    }
    const profileContext = pageUrl(doc)?.pathname.endsWith('/user.php') || /Уровень\s*:?\s*\d+/i.test(body);
    if (profileContext) {
      for (const heading of doc.querySelectorAll('.main h1, .profile h1, main h1, h1')) {
        const nick = cleanNick(heading.textContent);
        if (nick) return nick;
      }
      return cleanNick(String(doc.title || '').split(/[—|]/)[0]);
    }
    return null;
  }

  function labelledValues(doc) {
    const result = {};
    for (const key of doc.querySelectorAll('.dw-kv__k')) {
      const row = key.closest('.dw-kv__row') || key.parentElement;
      const value = row?.querySelector('.dw-kv__v') || key.nextElementSibling;
      const label = clean(key.textContent).replace(/:$/, '');
      if (label && value) result[label.toLowerCase()] = clean(value.textContent);
    }
    return result;
  }

  function parseCharacter(input) {
    const doc = toDocument(input);
    if (!doc?.body) return null;
    const body = clean(doc.body.textContent);
    const values = labelledValues(doc);
    const result = {};
    const nick = findNick(doc);
    if (nick) {
      result.nick = nick;
      result.name = nick;
    }

    const level = values['уровень']?.match(/\d+/)?.[0] || body.match(/Уровень\s*:?\s*(\d+)/i)?.[1];
    const city = values['сейчас в']?.match(/[А-Яа-яЁё][А-Яа-яЁё\s-]*?(?=\s+\[|$)/)?.[0]
      || body.match(/Сейчас в\s*:?\s*([А-Яа-яЁё][А-Яа-яЁё-]*?)(?=Уровень\s*:|Сторона\s*:|Клан|Очки|\s|$)/i)?.[1];
    const side = values['сторона']?.match(/(Дреды|Темплары|Тени|Свет)/i)?.[0]
      || body.match(/Сторона\s*:?\s*(?:\S+\s+){0,2}?(Дреды|Темплары|Тени|Свет)/i)?.[1];
    const od = values['очки доблести']?.match(/\d+/)?.[0] || body.match(/Очки Доблести\s*:?\s*(\d+)/i)?.[1];
    const os = values['очки славы']?.match(/\d+/)?.[0] || body.match(/Очки Славы\s*:?\s*(\d+)/i)?.[1];
    if (level) result.lvl = level;
    if (city) result.city = clean(city);
    if (side) result.side = clean(side);
    if (od) result.od = od;
    if (os) result.os = os;

    const clan = links(doc, 'a[href*="clan.php"][href*="id="]').find(anchor => parameter(anchor.href, 'id'));
    if (clan) result.clan_id = parameter(clan.href, 'id');
    if (/Герой Грез Войны|Герой Грёз Войны/i.test(body)) result.is_hero = true;
    return Object.keys(result).length ? result : null;
  }

  function isForeignProfile(doc) {
    const current = pageUrl(doc);
    return Boolean(current && current.pathname.endsWith('/user.php') && current.searchParams.has('id'));
  }

  function supports(kind, input) {
    const doc = toDocument(input);
    if (!doc) return false;
    const current = pageUrl(doc);
    // DOMParser не сохраняет адрес. Разметка фикстур проверяется самими селекторами.
    if (!current) return ['folders', 'scrolls', 'kits', 'skills', 'classSkills', 'quests', 'teleports'].includes(kind);
    const path = current.pathname.toLowerCase();
    const mode = (name) => current.searchParams.get(name) === '1';
    if (kind === 'folders') return path.endsWith('/inventory.php') && mode('chest');
    if (kind === 'scrolls') return path.endsWith('/inventory.php');
    if (kind === 'kits') return path.endsWith('/inventory.php') && mode('wearkit');
    if (kind === 'skills') {
      return (path.endsWith('/skill_learn.php') && mode('myskills')) || path.endsWith('/myskills.php');
    }
    if (kind === 'classSkills') return path.endsWith('/class.php') && mode('myskills');
    if (kind === 'quests') return path.endsWith('/leader.php') || path.endsWith('/quests.php');
    if (kind === 'teleports') {
      return /\/(?:world\/(?:tower|towers|castle)\.php|clan\.php)$/i.test(path);
    }
    return false;
  }

  function scanFolders(input) {
    const doc = toDocument(input);
    if (!supports('folders', doc)) return null;
    const items = links(doc, 'a[href*="folder="]').filter(anchor => {
      return parameter(anchor.href, 'chest') === '1' && parameter(anchor.href, 'folder');
    }).map(anchor => ({
      id: parameter(anchor.href, 'folder'),
      name: clean(anchor.textContent).replace(/\s*\[\d+\]\s*$/, '').trim()
    })).filter(item => item.name);
    return unique(items);
  }

  function scanSkills(input, options = {}) {
    const doc = toDocument(input);
    if (!supports('skills', doc)) return null;
    const skillRoot = doc.querySelector('.dw-lots.dw-sk__list') || doc;
    const items = links(skillRoot, 'a[href*="info="]').map(anchor => ({
      id: parameter(anchor.href, 'info'),
      name: clean(anchor.textContent),
      value: false,
      group: '0'
    })).filter(item => item.name);
    const result = unique(items);
    const user = options.user || {};
    if (Number(user.os) > 1200) result.push({ name: 'Призвать Духа', id: '175', value: false, group: '0' });
    if (user.is_hero) result.push({ name: 'Благословление Героя', id: '183', value: false, group: '0' });
    if (options.rageStage) result.push(options.rageStage);
    result.push(
      { name: 'Призыв Рыцаря', id: '184', value: false, group: '0', tooltip: 'Если есть - будет работать' },
      { name: 'Призыв Командора', id: '185', value: false, group: '0', tooltip: 'Если есть - будет работать' }
    );
    return unique(result);
  }

  function itemName(anchor) {
    const container = anchor.closest('.dw-lot, .dw-item, .inventory-item, tr, .block, .pad') || anchor.parentElement;
    const named = container?.querySelector('.dw-lot__name, .dw-pick__name, .item-name, [data-item-name]');
    const own = clean(anchor.textContent);
    const candidate = clean(named?.textContent || container?.querySelector('b, strong')?.textContent || own);
    if (candidate && !/^(?:переместить|снять|на пояс|в рюкзак|использовать)$/i.test(candidate)) return candidate;
    return clean(anchor.getAttribute('title') || anchor.getAttribute('data-name') || candidate);
  }

  function scanScrolls(input) {
    const doc = toDocument(input);
    if (!supports('scrolls', doc)) return null;
    const items = links(doc, 'a[href*="moveMagic=1"][href*="item_id="]').map(anchor => ({
      id: parameter(anchor.href, 'item_id'),
      name: itemName(anchor),
      value: '0'
    })).filter(item => item.name);
    return unique(items);
  }

  function scanKits(input) {
    const doc = toDocument(input);
    if (!supports('kits', doc)) return null;
    const items = links(doc, 'a[href*="wearkit=1"][href*="id="]').map(anchor => ({
      id: parameter(anchor.href, 'id'),
      name: clean(anchor.textContent)
    })).filter(item => item.name);
    return unique(items);
  }

  function classBonuses(doc) {
    const result = {};
    for (const row of doc.querySelectorAll('.dw-lot__who')) {
      const name = clean(row.querySelector('.dw-lot__name')?.textContent);
      const value = clean(row.querySelector('.dw-lot__cap')?.textContent);
      if (name && value) result[name.toLowerCase()] = value;
    }
    return result;
  }

  function scanClassSkills(input) {
    const doc = toDocument(input);
    if (!supports('classSkills', doc)) return null;
    const body = clean(doc.body.textContent);
    const pointsText = clean(doc.querySelector('.dw-cl__htext .dw-cl__hmeta b')?.textContent);
    const points = Number(pointsText || body.match(/У\s*Вас\s+(\d+)\s+очков\s+Класса/i)?.[1] || 0);
    const bonuses = classBonuses(doc);
    const seen = new Set();
    const list = [];

    for (const anchor of links(doc, 'a[href*="class.php"][href*="skill="], a[href*="up=1"][href*="skill="]')) {
      const id = parameter(anchor.href, 'skill');
      if (!id || seen.has(id)) continue;
      const container = anchor.closest('.dw-lot, .dw-cl__skill, .dw-skill, tr, .block, .pad') || anchor.parentElement;
      const fullText = clean(container?.textContent || anchor.textContent);
      const name = clean(container?.querySelector('.dw-lot__name, .dw-cl__name, .dw-skill__name, b, strong')?.textContent || anchor.textContent)
        .replace(/^\d+\.\s*/, '').replace(/\s*(?:Уровень|Текущий уровень).*$/i, '').trim();
      if (!name) continue;
      seen.add(id);
      const level = fullText.match(/(?:Текущий уровень умения\s*:|Уровень)\s*(\d+)/i)?.[1] || '0';
      const detailsText = clean(container?.querySelector('.dw-lot__cap')?.textContent || fullText);
      const bonusMatch = detailsText.match(/Уровень\s+\d+\s+из\s+\d+\s*·\s*(.+?)\s*·\s*сейчас\s+(.+)/i);
      list.push({
        id, name, lvl: level,
        bonus: bonusMatch ? `${clean(bonusMatch[1])} (${clean(bonusMatch[2])})` : bonuses[name.toLowerCase()] || null
      });
    }

    // Новый интерфейс может показывать классовые умения без ссылок повышения.
    if (!list.length) {
      for (const row of doc.querySelectorAll('.dw-lot__who')) {
        const name = clean(row.querySelector('.dw-lot__name')?.textContent);
        const details = clean(row.querySelector('.dw-lot__cap')?.textContent);
        const match = details.match(/Уровень\s+(\d+)\s+из\s+\d+\s*·\s*(.+?)\s*·\s*сейчас\s+(.+)/i);
        if (name && match) list.push({ id: null, name, lvl: match[1], bonus: `${clean(match[2])} (${clean(match[3])})` });
      }
    }
    return { points, list };
  }

  function scanTeleports(input) {
    const doc = toDocument(input);
    if (!supports('teleports', doc)) return null;
    const towers = unique(links(doc, 'a[href*="tower.php"][href*="id="]').map(anchor => ({
      id: Number(parameter(anchor.href, 'id'))
    }))).map(item => item.id);
    const castles = unique(links(doc, 'a[href*="castle.php"][href*="id="]').map(anchor => ({
      id: Number(parameter(anchor.href, 'id'))
    }))).map(item => item.id);
    if (!towers.length && !castles.length) return null;
    return { towers, castles };
  }

  return Object.freeze({
    parseCharacter, isForeignProfile, supports, scanFolders, scanSkills,
    scanScrolls, scanKits, scanClassSkills, scanTeleports
  });
})();
