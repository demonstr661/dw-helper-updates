globalThis.smartWorldRecoveryBusy = false;

globalThis.useWorldConsumable = async function useWorldConsumable({ kind }) {
  const links = [...document.querySelectorAll('a[href]')];
  let link = null;
  if (kind === 'scroll59') {
    link = links.find(anchor => {
      if (!anchor.href.includes('/useItem.php')) return false;
      try { return new URL(anchor.href).searchParams.get('item_id') === '59'; } catch (_) { return false; }
    });
  } else if (kind === 'balance') {
    link = links.find(anchor => /равновес/i.test(anchor.textContent || '') && anchor.href);
  }
  if (!link) return false;
  // Ссылка берётся только из текущего DOM и нигде не сохраняется. Повторов нет.
  await fetchPage(link.href, { redirect: 'manual' });
  return true;
}

globalThis.recoverSmartRoute = async function recoverSmartRoute({ failedHotkey = '', failedTo = null } = {}) {
  if (!state.smartWorld?.enabled || smartWorldRecoveryBusy) return false;
  globalThis.smartWorldRecoveryBusy = true;
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'recover-world-route',
      payload: { fromLocation: currentLocation(), failedHotkey, failedTo }
    });
    if (response?.recovered && Array.isArray(response.steps)) {
      state.move.routes = [response.steps];
      state.move.active = 0;
      state.move.step = 0;
      state.move.location = null;
      await updateState({ move: state.move });
      notify(`Переход ${response.blockedEdge} исключён. Найден альтернативный путь.`);
      refresh();
      return true;
    }
    if (response?.reason !== 'no-path') return false;

    for (const [kind, label] of [['scroll59', 'Свиток item id 59'], ['balance', 'Камень равновесия']]) {
      const allowed = kind === 'scroll59' ? state.smartWorld.allowScroll59 : state.smartWorld.allowBalanceStones;
      if (!allowed || state.smartWorld.consumableAttempts?.[kind]) continue;
      const used = await chrome.runtime.sendMessage({ action: 'use-world-consumable', payload: { kind } });
      if (used) {
        notify(`${label}: выполнена одна разрешённая попытка.`);
        refresh();
        return true;
      }
    }
    notify('Альтернативных путей и разрешённых способов восстановления не осталось. Маршрут остановлен.');
    state.world.map = 0;
    state.move.routes = [];
    state.move.active = 0;
    state.move.step = 0;
    await updateState({ world: state.world, move: state.move });
    return true;
  } catch (_) {
    return false;
  } finally {
    globalThis.smartWorldRecoveryBusy = false;
  }
}
