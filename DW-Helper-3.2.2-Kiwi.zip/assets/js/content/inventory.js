waitToReadyState().then(async () => {
  const links = [...document.querySelectorAll('.block a[href*=fif]')];
  const mapping = state.global.newDesign ? dropTypes.new : dropTypes.old;
  const authParams = new Set(['UIN', 'uin', 'pass', 'sid']);

  function beltFilterFromPage() {
    const beltLink = links.find(link => /пояс/i.test(link.textContent || ''));
    if (!beltLink) return null;
    const beltUrl = new URL(beltLink.href);
    const otherUrls = links.filter(link => link !== beltLink).map(link => new URL(link.href));
    for (const [key, value] of beltUrl.searchParams) {
      if (authParams.has(key) || !value) continue;
      const shared = otherUrls.length && otherUrls.every(other => other.searchParams.get(key) === value);
      if (!shared) return { key, value };
    }
    return null;
  }

  const beltFilter = beltFilterFromPage();
  if (state.inventory_filters?.belts && !beltFilter) {
    notify('Фильтр поясов не найден на этой странице. Действие остановлено.');
    await endAction();
    return;
  }
  if (beltFilter) {
    const current = new URL(location.href);
    const desired = state.inventory_filters?.belts ? beltFilter.value : null;
    if ((current.searchParams.get(beltFilter.key) || null) !== desired) {
      if (desired === null) current.searchParams.delete(beltFilter.key);
      else current.searchParams.set(beltFilter.key, desired);
      redirect(current.href);
      return;
    }
  }
  for (const link of links) {
    const next = new URL(link.href);
    for (const [key, rawValue] of Object.entries(state.inventory_filters || {})) {
      if (key === 'belts') continue;
      const parameter = mapping[key];
      if (!parameter) continue;
      if (Boolean(Number(rawValue))) next.searchParams.set(parameter, String(Number(rawValue)));
      else next.searchParams.delete(parameter);
    }
    if (beltFilter) {
      if (state.inventory_filters?.belts) next.searchParams.set(beltFilter.key, beltFilter.value);
      else next.searchParams.delete(beltFilter.key);
    }
    link.href = next.href;
  }
  runFilter();
});
