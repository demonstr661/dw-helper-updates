// Общие технические паузы интерфейса и маршрутов.
// Сюда передаются только технические задержки, а не правила Поля битв.
function dwActionDelay(milliseconds) {
  const value = Number(milliseconds);
  if (!Number.isFinite(value) || value <= 0 || !state?.global?.faster) return value;
  return Math.max(100, Math.round(value * 0.35));
}
