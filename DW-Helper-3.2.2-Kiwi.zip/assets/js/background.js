importScripts('./chrome-compat.js', './worker/initial-state.js', './worker/geo.js');

const FILES = {
  runtime: 'assets/js/content/runtime-config.js',
  offline: 'assets/js/content/offline-scanner.js',
  dayjs: 'assets/js/vendor/dayjs.min.js',
  config: 'assets/js/content/config.js',
  main: 'assets/js/content/content-script.js',
  captcha: 'assets/js/resources/captchaClass.js',
  world: 'assets/js/content/world.js',
  worldSlave: 'assets/js/content/world-slave.js',
  battlefieldDate: 'assets/js/resources/battlefieldDate.js',
  battlefield: 'assets/js/content/battlefield.js',
  battleAI: 'assets/js/content/battle-ai.js',
  battles: 'assets/js/content/battles.js',
  inventory: 'assets/js/content/inventory.js',
  parcels: 'assets/js/content/parcels.js',
  totems: 'assets/js/content/totems.js',
  extract: 'assets/js/content/extract.js',
  castle: 'assets/js/content/castle.js',
  craft: 'assets/js/content/craft.js',
  mainPage: 'assets/js/content/main-page.js',
  user: 'assets/js/content/user.js',
  smartWorld: 'assets/js/content/smart-world.js'
};

const QUESTS = {
  sulfurCollection: 4,
  helpInBattles: 6,
  assistanceInSieges: 7,
  secretMission: 8,
  enemySupplies: 10,
  importantSupplies: 11,
  attackTheEnemy: 14,
  defenceOfTerritories: 13,
  clearingTheLaboratory: 15,
  arenaBattle: 16,
  difficultArenaBattle: 17,
  colosseumQuest: 26
};

const BUFFS = {
  default: [-1, -2, -3, -4, -5, -7, -8, -9],
  defaultRage: [-6],
  advanced: [-101, -102, -103, -104, -105, -107, -108, -109],
  advancedRage: [-106]
};

const CAPTCHA_SERVICES = {
  capMonster: {
    value: 2, name: 'CapMonster Cloud', currency: 'USD',
    balanceUrl: 'https://api.capmonster.cloud/getBalance'
  },
  ruCaptcha: {
    value: 3, name: 'ruCaptcha', currency: 'RUB',
    balanceUrl: 'https://api.rucaptcha.com/getBalance'
  },
  antiCaptcha: {
    value: 4, name: 'Anti-Captcha', currency: 'USD',
    balanceUrl: 'https://api.anti-captcha.com/getBalance'
  }
};
const CBR_DAILY_URL = 'https://www.cbr.ru/scripts/XML_daily.asp';
const CAPTCHA_REFRESH_INTERVAL = 60_000;

const SCAN_ACTIONS = new Set([
  'parse-user', 'scan-folders', 'scan-skills', 'scan-scrolls',
  'scan-kit', 'scan-class-skills', 'scan-teleports', 'scan-quests'
]);
// Сканеры читают только конкретную, уже загруженную страницу. Навигация здесь запрещена.
// query задаёт обязательный режим страницы: без него HTML нужных данных обычно отсутствует.
const SCAN_TAB_PAGES = {
  'scan-folders': [{ path: '/inventory.php', query: { chest: '1' } }],
  'scan-skills': [
    { path: '/skill_learn.php', query: { myskills: '1' } },
    { path: '/myskills.php' }
  ],
  'scan-scrolls': [{ path: '/inventory.php' }],
  'scan-kit': [{ path: '/inventory.php', query: { wearkit: '1' } }],
  'scan-class-skills': [{ path: '/class.php', query: { myskills: '1' } }],
  'scan-teleports': [
    { path: '/world/tower.php' }, { path: '/world/towers.php' },
    { path: '/world/castle.php' }, { path: '/clan.php' }
  ],
  'scan-quests': [{ path: '/leader.php' }, { path: '/quests.php' }]
};
const SCAN_PAGE_LABELS = {
  'scan-folders': 'инвентарь → отделы (inventory.php?chest=1)',
  'scan-skills': 'мои умения (skill_learn.php?myskills=1)',
  'scan-scrolls': 'инвентарь со свитками',
  'scan-kit': 'комплекты (inventory.php?wearkit=1)',
  'scan-class-skills': 'классовые умения (class.php?myskills=1)',
  'scan-teleports': 'список башен или замков',
  'scan-quests': 'задания (leader.php)'
};
const ITEM_ACTIONS = new Set(['merge-items', 'break-items', 'gain-item']);
const BATTLEGROUND_ACTIONS = new Set([
  'create-battleground', 'ready-battleground', 'self-battleground'
]);
const DIRECT_ACTIONS = new Set(['grade-item']);
const STUCK_TIMEOUT = 10_000;
const SLEEP_ALARM = 'dw-helper-sleep';

const state = structuredClone(initialState);
const monitoredTabs = new Map();
const readyTabs = new Set();
let stateReadyPromise = null;
let captchaRequestId = 0;
let usdRateCache = { value: null, loadedAt: 0 };

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function mergeDefaults(defaults, saved) {
  if (!isPlainObject(defaults) || !isPlainObject(saved)) {
    return saved === undefined ? structuredClone(defaults) : saved;
  }
  const result = {};
  for (const [key, value] of Object.entries(defaults)) {
    result[key] = isPlainObject(value) && isPlainObject(saved[key])
      ? mergeDefaults(value, saved[key])
      : saved[key] === undefined ? structuredClone(value) : saved[key];
  }
  for (const [key, value] of Object.entries(saved)) {
    if (!(key in result)) result[key] = value;
  }
  return result;
}

function sanitizeState(saved) {
  const clean = structuredClone(saved || {});
  if (isPlainObject(clean.popup) && Number(clean.popup.navigationVersion) !== 2) {
    const previousTab = Number(clean.popup.activeTab) || 0;
    const previousAccordion = Number(clean.popup.activeAccordion) || 0;
    const tabMap = { 0: 0, 1: 1, 2: 2, 3: 2, 4: 3, 5: 4, 6: 5, 7: 5 };
    const accordionMaps = {
      2: { 0: 0, 1: 3, 2: 4 },
      3: { 0: 1, 1: 2 },
      6: { 0: 0, 1: 1, 2: 2, 3: 3, 4: 7 },
      7: { 0: 4, 1: 5, 2: 6 }
    };
    clean.popup.activeTab = tabMap[previousTab] ?? 0;
    clean.popup.activeAccordion = accordionMaps[previousTab]?.[previousAccordion] ?? 0;
    clean.popup.navigationVersion = 2;
  }
  const savedCaptcha = isPlainObject(clean.captcha) ? clean.captcha : {};
  const legacyValue = Number(clean.global?.captcha || 0);
  const legacyService = Object.keys(CAPTCHA_SERVICES)
    .find((key) => CAPTCHA_SERVICES[key].value === legacyValue) || null;
  const unifiedToken = typeof savedCaptcha.token === 'string' ? savedCaptcha.token.trim() : '';
  const legacyToken = legacyService && typeof savedCaptcha[legacyService]?.token === 'string'
    ? savedCaptcha[legacyService].token.trim()
    : '';
  const token = unifiedToken || legacyToken;
  const service = CAPTCHA_SERVICES[savedCaptcha.service] ? savedCaptcha.service : legacyService;
  clean.captcha = {
    token,
    service: token ? service : null,
    status: token && service ? 'ready' : 'idle',
    balance: Number.isFinite(savedCaptcha.balance) ? savedCaptcha.balance : null,
    balanceRub: Number.isFinite(savedCaptcha.balanceRub) ? savedCaptcha.balanceRub : null,
    currency: service ? CAPTCHA_SERVICES[service].currency : null,
    usdRate: Number.isFinite(savedCaptcha.usdRate) ? savedCaptcha.usdRate : null,
    updatedAt: Number.isFinite(savedCaptcha.updatedAt) ? savedCaptcha.updatedAt : null,
    error: ''
  };
  if (clean.global) {
    delete clean.global.isPrime;
    delete clean.global.primeTime;
    clean.global.captcha = token && service ? CAPTCHA_SERVICES[service].value : 0;
    if (!/^#[\da-f]{6}$/i.test(clean.global.themeColor || '')) {
      clean.global.themeColor = initialState.global.themeColor;
    }
  }
  delete clean.secure;
  return clean;
}

async function ensureStateReady() {
  if (!stateReadyPromise) {
    stateReadyPromise = DW_API.storageGet(null).then((saved) => {
      const merged = mergeDefaults(initialState, sanitizeState(saved));
      for (const key of Object.keys(state)) delete state[key];
      Object.assign(state, merged);
    });
  }
  return stateReadyPromise;
}

function isGameUrl(url = '') {
  return /^https?:\/\/(?:[^/]+\.)?dreamwar\.ru(?:\/|$)/i.test(url);
}

function matchesScanPage(tab, action) {
  const pages = SCAN_TAB_PAGES[action];
  if (!pages) return true;
  try {
    const current = new URL(tab.url);
    const pathname = current.pathname.toLowerCase();
    return pages.some((page) => {
      if (!pathname.endsWith(page.path)) return false;
      return Object.entries(page.query || {}).every(([name, value]) => {
        return current.searchParams.get(name) === value;
      });
    });
  } catch (_) {
    return false;
  }
}

async function getGameTab(action = null) {
  const tabs = await DW_API.tabsQuery({ status: 'complete' });
  const gameTabs = tabs.filter((tab) => isGameUrl(tab.url));
  const candidates = SCAN_TAB_PAGES[action]
    ? gameTabs.filter((tab) => matchesScanPage(tab, action))
    : gameTabs;
  return candidates.find((tab) => tab.active) || candidates[0];
}

function isConnectionError(error) {
  return /could not establish connection|receiving end does not exist/i.test(error?.message || '');
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function waitForGameTab(tabId, timeout = 5000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    if (readyTabs.has(tabId)) return true;
    await delay(100);
  }
  return readyTabs.has(tabId);
}

async function injectContentCore(tabId) {
  await DW_API.scriptingExecute({
    target: { tabId },
    files: [FILES.runtime, FILES.dayjs, FILES.config, FILES.offline, FILES.main]
  });
}

async function fetchWithTimeout(url, options = {}, timeout = 10_000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response;
  } finally {
    clearTimeout(timer);
  }
}

async function getUsdRate() {
  if (usdRateCache.value && Date.now() - usdRateCache.loadedAt < 6 * 60 * 60 * 1000) {
    return usdRateCache.value;
  }
  const response = await fetchWithTimeout(CBR_DAILY_URL);
  const xml = await response.text();
  const block = xml.match(/<Valute\b[^>]*>[\s\S]*?<CharCode>USD<\/CharCode>[\s\S]*?<\/Valute>/)?.[0];
  const nominal = Number(block?.match(/<Nominal>(\d+)<\/Nominal>/)?.[1] || 1);
  const value = Number(block?.match(/<Value>([\d,]+)<\/Value>/)?.[1]?.replace(',', '.'));
  if (!Number.isFinite(value) || !Number.isFinite(nominal) || nominal <= 0) {
    throw new Error('Курс USD не получен');
  }
  const rate = value / nominal;
  usdRateCache = { value: rate, loadedAt: Date.now() };
  return rate;
}

async function connectCaptcha(tokenValue, refresh = false) {
  const requestId = ++captchaRequestId;
  const token = String(tokenValue ?? '').trim();
  if (!token) {
    await setState({
      captcha: structuredClone(initialState.captcha),
      global: { ...state.global, captcha: 0 }
    });
    return true;
  }

  const previous = state.captcha || initialState.captcha;
  const preferred = refresh && previous.token === token && CAPTCHA_SERVICES[previous.service]
    ? previous.service
    : null;
  await setState({
    captcha: { ...structuredClone(initialState.captcha), token, service: preferred, status: 'checking' },
    global: { ...state.global, captcha: 0 }
  });

  const order = preferred
    ? [preferred, ...Object.keys(CAPTCHA_SERVICES).filter((key) => key !== preferred)]
    : Object.keys(CAPTCHA_SERVICES);
  let detected = null;
  let networkFailed = false;
  let lastErrorCode = '';
  for (const service of order) {
    if (requestId !== captchaRequestId) return true;
    try {
      const response = await fetchWithTimeout(CAPTCHA_SERVICES[service].balanceUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ clientKey: token })
      });
      const data = await response.json();
      if (requestId !== captchaRequestId) return true;
      const balance = Number(data.balance);
      if (Number(data.errorId) === 0 && data.balance !== null && Number.isFinite(balance)) {
        detected = { service, balance };
        break;
      }
      lastErrorCode = data.errorCode || data.errorDescription || lastErrorCode;
    } catch (_) {
      if (requestId !== captchaRequestId) return true;
      networkFailed = true;
    }
  }
  if (requestId !== captchaRequestId) return true;

  if (!detected) {
    const error = networkFailed
      ? 'Не удалось проверить токен: сервисы капчи не отвечают.'
      : `Сервис не определён. Проверьте токен.${lastErrorCode ? ` ${lastErrorCode}` : ''}`;
    await setState({
      captcha: { ...structuredClone(initialState.captcha), token, status: 'error', error },
      global: { ...state.global, captcha: 0 }
    });
    return true;
  }

  const config = CAPTCHA_SERVICES[detected.service];
  let balanceRub = config.currency === 'RUB' ? detected.balance : null;
  let usdRate = null;
  let conversionError = '';
  if (config.currency === 'USD') {
    try {
      usdRate = await getUsdRate();
      balanceRub = detected.balance * usdRate;
    } catch (_) {
      conversionError = 'Курс ЦБ недоступен: порог цвета не рассчитан.';
    }
  }
  if (requestId !== captchaRequestId) return true;
  await setState({
    captcha: {
      token,
      service: detected.service,
      status: 'ready',
      balance: detected.balance,
      balanceRub,
      currency: config.currency,
      usdRate,
      updatedAt: Date.now(),
      error: conversionError
    },
    global: { ...state.global, captcha: config.value }
  });
  return true;
}

function formatChanges(patch, previous) {
  const changes = {};
  for (const [section, value] of Object.entries(patch)) {
    if (JSON.stringify(previous[section]) !== JSON.stringify(value)) {
      changes[section] = { oldValue: previous[section], newValue: value };
    }
  }
  return changes;
}

async function broadcastChanges(patch, previous) {
  const changes = formatChanges(patch, previous);
  if (!Object.keys(changes).length) return;
  const tab = await getGameTab();
  if (tab) {
    DW_API.tabsSendMessage(tab.id, { action: 'update-state', payload: changes }).catch(() => {});
  }
  DW_API.runtimeSendMessage({ action: 'update-state', payload: patch }).catch(() => {});
}

async function setState(patch) {
  await ensureStateReady();
  const previous = structuredClone(state);
  Object.assign(state, structuredClone(patch));
  await DW_API.storageSet(patch);
  await broadcastChanges(patch, previous);
}

async function resetState() {
  await ensureStateReady();
  await DW_API.alarmsClear(SLEEP_ALARM);
  await DW_API.storageClear();
  const fresh = structuredClone(initialState);
  for (const key of Object.keys(state)) delete state[key];
  Object.assign(state, fresh);
  await DW_API.storageSet(fresh);
  DW_API.runtimeSendMessage({ action: 'update-state', payload: fresh }).catch(() => {});
}

async function setBadge(text = '', color = 'blue') {
  await DW_API.badgeText({ text });
  await DW_API.badgeColor({ color });
}

async function setupOffscreen() {
  if (await chrome.offscreen.hasDocument?.()) return;
  await chrome.offscreen.createDocument({
    url: 'assets/src/notify/audio.html',
    reasons: [chrome.offscreen.Reason.AUDIO_PLAYBACK],
    justification: 'Звуковые уведомления DW Helper'
  });
}

function playSound() {
  setupOffscreen()
    .then(() => DW_API.runtimeSendMessage({ type: 'PLAY_AUDIO' }))
    .catch(() => {});
}

function showMessage(payload = {}) {
  const text = String(payload.text || payload.message || 'Неизвестное уведомление');
  const entry = `[${new Date().toLocaleString()}] ${text}`;
  setState({ popup: { ...state.popup, logs: [...(state.popup.logs || []), entry].slice(-30) } })
    .catch(() => {});
  chrome.notifications.create(`dwhelper_${payload.date || Date.now()}`, {
    type: 'basic',
    iconUrl: chrome.runtime.getURL('assets/src/dw128.png'),
    title: payload.warn ? 'Внимание!' : 'Информация',
    message: text
  }, () => {
    const error = chrome.runtime.lastError;
    if (error) return;
    if (payload.warn || state.global.sound) playSound();
  });
}

async function updatePopup(activeTab = 0, activeAccordion = 0) {
  await setState({ popup: { ...state.popup, activeTab, activeAccordion } });
}

async function requestGameTab(tabId, message) {
  const response = await DW_API.tabsSendMessage(tabId, message);
  if (response === undefined) throw new Error('Не получен ответ от вкладки игры');
  return response;
}

async function sendToGame(message) {
  const tab = await getGameTab(message.action);
  if (!tab) {
    const page = SCAN_PAGE_LABELS[message.action];
    if (page) {
      throw new Error(`Офлайн-сканирование: загруженная страница «${page}» не найдена среди открытых вкладок. Откройте её вручную и повторите. Расширение не выполняло сетевых запросов.`);
    }
    throw new Error('Вкладка Dreamwar.ru не найдена');
  }
  try {
    return await requestGameTab(tab.id, message);
  } catch (error) {
    if (!isConnectionError(error)) throw error;
  }

  // Команда ещё не была принята страницей: короткий повтор безопасен.
  await delay(300);
  try {
    return await requestGameTab(tab.id, message);
  } catch (error) {
    if (!isConnectionError(error)) throw error;
  }

  // Слушателя действительно нет: восстанавливаем базовый скрипт и ждём готовности.
  readyTabs.delete(tab.id);
  await injectContentCore(tab.id);
  if (!await waitForGameTab(tab.id)) {
    throw new Error('Страница игры ещё загружается. Дождитесь её полной загрузки и повторите.');
  }
  return requestGameTab(tab.id, message);
}

function questCompletedToday(entry) {
  if (entry?.status !== 'completed') return false;
  const timestamp = Date.parse(entry.updatedAt || '');
  if (!Number.isFinite(timestamp)) return false;
  const completedAt = new Date(timestamp);
  const now = new Date();
  return completedAt.getFullYear() === now.getFullYear()
    && completedAt.getMonth() === now.getMonth()
    && completedAt.getDate() === now.getDate();
}

function selectedQuestIds() {
  return Object.entries(state.quests)
    .filter(([key, enabled]) => enabled && QUESTS[key] !== undefined && !questCompletedToday(state.questStatus?.[key]))
    .map(([key]) => QUESTS[key]);
}

function buffIds(kind) {
  const ids = [...BUFFS[kind]];
  if (state.global.withRage) ids.push(...BUFFS[`${kind}Rage`]);
  return ids;
}

async function scheduleSleep(value) {
  await DW_API.alarmsClear(SLEEP_ALARM);
  if (!value) return;
  const when = new Date(value).getTime();
  if (!Number.isFinite(when)) return;
  if (when <= Date.now()) {
    await setState({ global: { ...state.global, sleep: null, run: false } });
    return;
  }
  await chrome.alarms.create(SLEEP_ALARM, { when });
}

async function handleStateUpdate(message) {
  let patch = structuredClone(message.payload || {});
  if (message.type === 'badge') {
    await setBadge(patch.text, patch.color);
  }
  if (message.type === 'sleep') {
    await scheduleSleep(patch.global?.sleep);
  }
  if (message.type === 'cancel-sleep') {
    await DW_API.alarmsClear(SLEEP_ALARM);
  }
  if (message.from === 'popup' && message.type === 'update' && patch.move?.active === 0) {
    // Полный сброс выполняется только по явному действию интерфейса.
    // Content script использует active = 0 для запуска нового или альтернативного маршрута.
    patch.move = structuredClone(initialState.move);
    patch.temp = { ...state.temp, last_map: { id: null, isRestart: false } };
  }
  if (patch.popup?.allQuests !== undefined && patch.popup.allQuests !== state.popup.allQuests) {
    patch.quests = { ...(patch.quests || state.quests) };
    for (const key of Object.keys(state.quests)) {
      patch.quests[key] = patch.popup.allQuests && !questCompletedToday(state.questStatus?.[key]);
    }
  }
  await setState(patch);
}

async function handleScan(action) {
  const response = await sendToGame({ action });
  if (action === 'parse-user') {
    if (!isPlainObject(response?.user) || !Object.keys(response.user).length) {
      throw new Error('Офлайн-сканирование: откройте свой профиль или главную страницу игры и повторите.');
    }
  }
  if (isPlainObject(response)) {
    await setState(response);
    return true;
  }
  // Некоторые сканеры сами обновляют состояние и возвращают только подтверждение.
  if (response === true) return true;
  const page = SCAN_PAGE_LABELS[action] || 'игры';
  throw new Error(`Офлайн-сканирование: на открытой странице «${page}» не найдены нужные данные. Проверьте раздел и повторите. Расширение не выполняло сетевых запросов.`);
}

function compareVersions(left, right) {
  const a = String(left || '0').split('-')[0].split('.').map(Number);
  const b = String(right || '0').split('-')[0].split('.').map(Number);
  for (let index = 0; index < 3; index++) {
    const difference = (a[index] || 0) - (b[index] || 0);
    if (difference) return Math.sign(difference);
  }
  return 0;
}

async function checkForUpdates() {
  const metadataUrl = String(state.update?.metadataUrl || '').trim();
  if (!metadataUrl) {
    await setState({ update: { ...state.update, status: 'idle', error: 'Укажите официальный URL метаданных обновления.' } });
    return false;
  }
  let parsed;
  try {
    parsed = new URL(metadataUrl);
    if (parsed.protocol !== 'https:') throw new Error('Нужен HTTPS URL');
    await setState({ update: { ...state.update, status: 'checking', error: '' } });
    const response = await fetchWithTimeout(parsed.href, { cache: 'no-store' });
    const metadata = await response.json();
    if (!/^\d+\.\d+\.\d+(?:-[a-z\d.-]+)?$/i.test(String(metadata.version || ''))) {
      throw new Error('Метаданные не содержат корректную версию');
    }
    let downloadUrl = '';
    if (metadata.downloadUrl) {
      const download = new URL(metadata.downloadUrl);
      if (download.protocol !== 'https:') throw new Error('Ссылка обновления должна использовать HTTPS');
      downloadUrl = download.href;
    }
    const available = compareVersions(metadata.version, chrome.runtime.getManifest().version) > 0;
    await setState({ update: {
      ...state.update, metadataUrl: parsed.href, latestVersion: String(metadata.version),
      downloadUrl, notes: String(metadata.notes || '').slice(0, 500),
      status: available ? 'available' : 'current', error: '', lastCheckedAt: Date.now()
    } });
    if (available) showMessage({ text: `Доступно обновление призрак·dw ${metadata.version}. Откройте «Настройки → Обновление».` });
    return true;
  } catch (error) {
    await setState({ update: { ...state.update, status: 'error', error: error.message, lastCheckedAt: Date.now() } });
    return false;
  }
}


async function handleMessage(message, sender) {
  await ensureStateReady();
  const action = message.action;
  if (action === 'get-state') {
    if (sender.tab?.id !== undefined && isGameUrl(sender.tab.url)) {
      readyTabs.add(sender.tab.id);
    }
    return structuredClone(state);
  }
  if (action === 'clear-state') {
    await resetState();
    return true;
  }
  if (action === 'set-state') {
    await handleStateUpdate(message);
    return true;
  }
  if (action === 'connect-captcha') {
    return connectCaptcha(message.payload?.token, Boolean(message.payload?.refresh));
  }
  if (action === 'check-update') return checkForUpdates();
  if (action === 'open-update') {
    if (state.update?.status !== 'available' || !state.update.downloadUrl) return false;
    const url = new URL(state.update.downloadUrl);
    if (url.protocol !== 'https:') return false;
    await DW_API.tabsCreate({ url: url.href, active: true });
    return true;
  }
  if (action === 'clear-battle-ai') {
    await setState({ battleAI: { ...state.battleAI, memory: {}, lastDecision: null, lastObservation: null } });
    return true;
  }
  if (action === 'preview-sale') {
    const response = await sendToGame({ action });
    if (!Array.isArray(response?.items)) return false;
    const items = response.items.slice(0, 200).map((item, index) => ({
      id: String(item.id || `${index}:`).slice(0, 100),
      name: String(item.name || 'Вещь').replace(/\s+/g, ' ').trim().slice(0, 180) || 'Вещь'
    }));
    await setState({ inventoryPreview: {
      status: items.length ? 'ready' : 'empty', items,
      createdAt: new Date().toISOString(), error: ''
    } });
    return true;
  }
  if (action === 'confirm-sale') {
    const preview = state.inventoryPreview || initialState.inventoryPreview;
    if (preview.status !== 'ready' || !Array.isArray(preview.items) || !preview.items.length) return false;
    const response = await sendToGame({ action, payload: { ids: preview.items.map(item => item.id) } });
    if (response === true) {
      await setState({ inventoryPreview: structuredClone(initialState.inventoryPreview) });
      return true;
    }
    return false;
  }
  if (action === 'cancel-sale-preview') {
    await setState({ inventoryPreview: structuredClone(initialState.inventoryPreview) });
    return true;
  }
  if (action === 'clear-sales') {
    await setState({ inventoryReport: structuredClone(initialState.inventoryReport) });
    return true;
  }
  if (action === 'sale-progress') {
    const report = message.payload || {};
    const cleanItems = Array.isArray(report.items) ? report.items.slice(-50).map(item => ({
      name: String(item.name || 'Вещь').slice(0, 180),
      confirmed: Boolean(item.confirmed),
      amounts: item.amounts && typeof item.amounts === 'object' ? item.amounts : {}
    })) : [];
    await setState({ inventoryReport: {
      status: ['idle', 'running', 'done'].includes(report.status) ? report.status : 'idle',
      processed: Math.max(0, Number(report.processed) || 0),
      total: Math.max(0, Number(report.total) || 0),
      succeeded: Math.max(0, Number(report.succeeded) || 0),
      failed: Math.max(0, Number(report.failed) || 0),
      amounts: report.amounts && typeof report.amounts === 'object' ? report.amounts : {},
      items: cleanItems,
      startedAt: report.startedAt || null,
      finishedAt: report.finishedAt || null
    } });
    return true;
  }
  if (action === 'clear-logs') {
    await setState({ popup: { ...state.popup, logs: [] } });
    return true;
  }
  if (action === 'show-message') {
    showMessage(message.payload || {});
    return true;
  }
  if (SCAN_ACTIONS.has(action)) return handleScan(action);
  if (action === 'validate') return { accepted: true };
  if (action === 'take-quests' || action === 'pass-quests') {
    const response = await sendToGame({
      action,
      payload: { ids: selectedQuestIds(), key: action === 'pass-quests' ? 'use' : 'get' }
    });
    if (response) {
      try {
        const scanned = await sendToGame({ action: 'scan-quests' });
        if (isPlainObject(scanned?.questStatus)) await setState({ questStatus: scanned.questStatus });
      } catch (_) {
        // Действие уже выполнено; не повторяем его ради обновления статусов.
      }
    }
    return response;
  }
  if (action === 'default-buffs' || action === 'advanced-buffs') {
    const kind = action === 'default-buffs' ? 'default' : 'advanced';
    return sendToGame({ action: 'take-buffs', payload: { ids: buffIds(kind) } });
  }
  if (action === 'gradeon' || action === 'gradeoff') {
    return sendToGame({ action: 'flasks', payload: { type: action } });
  }
  if (ITEM_ACTIONS.has(action)) return sendToGame({ action });
  if (BATTLEGROUND_ACTIONS.has(action)) {
    const [type, command] = action.split('-');
    return sendToGame({ action: command, type });
  }
  if (DIRECT_ACTIONS.has(action)) return sendToGame({ action });
  if (action === 'changed-user') {
    setTimeout(() => loadDynamicValues(false).catch(() => {}), 60_000);
    return true;
  }
  if (action === 'add-class-points') return sendToGame(message);
  if (action === 'build-route') {
    const request = message.payload || message.message;
    if (!state.smartWorld?.enabled) return buildFullRoute(request);
    const route = await buildSmartRoute({ ...request, blockedEdges: state.smartWorld.blockedEdges }, true);
    if (route) {
      await setState({ smartWorld: {
        ...state.smartWorld, currentDestination: route.destination,
        consumableAttempts: { scroll59: false, balance: false }, lastReason: ''
      } });
      return route.steps;
    }
    return null;
  }
  if (action === 'recover-world-route') {
    if (!state.smartWorld?.enabled) return { recovered: false, reason: 'disabled' };
    const from = Number(message.payload?.fromLocation);
    const failedHotkey = String(message.payload?.failedHotkey || '');
    const failedTo = Number(message.payload?.failedTo) || WORLD[from]?.[failedHotkey];
    const destination = Number(state.smartWorld.currentDestination);
    if (!from || !failedTo || !destination) return { recovered: false, reason: 'unknown-route' };
    const edge = `${from}:${failedTo}`;
    const blockedEdges = [...new Set([...state.smartWorld.blockedEdges, edge])].slice(-100);
    const route = await buildSmartRoute({ fromLocation: from, toLocation: destination, blockedEdges, silent: true }, true);
    if (route) {
      await setState({ smartWorld: { ...state.smartWorld, blockedEdges, lastReason: '' } });
      return { recovered: true, steps: route.steps, blockedEdge: edge };
    }
    await setState({ smartWorld: { ...state.smartWorld, blockedEdges, lastReason: `Путь недоступен: ${edge}` } });
    return { recovered: false, reason: 'no-path', blockedEdge: edge };
  }
  if (action === 'use-world-consumable') {
    const kind = message.payload?.kind;
    const allowed = kind === 'scroll59' ? state.smartWorld?.allowScroll59 : kind === 'balance' ? state.smartWorld?.allowBalanceStones : false;
    if (!allowed || state.smartWorld?.consumableAttempts?.[kind]) return false;
    await setState({ smartWorld: {
      ...state.smartWorld,
      consumableAttempts: { ...state.smartWorld.consumableAttempts, [kind]: true }
    } });
    return sendToGame({ action: 'use-world-consumable', payload: { kind } });
  }
  return false;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender)
    .then(sendResponse)
    .catch((error) => {
      try {
        showMessage({ warn: true, text: error.message });
      } catch (_) {
        // Ответ интерфейсу важнее вторичной ошибки уведомления.
      }
      sendResponse(SCAN_ACTIONS.has(message.action)
        ? { __dwHelperError: true, message: String(error.message || 'Ошибка офлайн-сканирования') }
        : false);
    });
  return true;
});

function stopMonitoring(tabId) {
  const monitor = monitoredTabs.get(tabId);
  if (!monitor) return;
  clearTimeout(monitor.timer);
  monitoredTabs.delete(tabId);
}

function startMonitoring(tabId, targetUrl = '') {
  const isBattle = targetUrl.includes('/battle_group.php');
  // Во время маршрута обычные переходы город/арена не считаются зависанием.
  if (!isBattle && state.global.run) { stopMonitoring(tabId); return; }
  if (!state.global.run && !state.global.useReloader) return;
  stopMonitoring(tabId);
  const timer = setTimeout(async () => {
    try {
      // На момент срабатывания настройка могла быть отключена пользователем.
      if (!state.global.run && !state.global.useReloader) return;
      const tab = await DW_API.tabsGet(tabId);
      const monitoredUrl = targetUrl || tab.url || '';
      if (monitoredUrl.includes('/battle_group.php')) {
        if (state.battles.run || state.global.useReloader) {
          // После перезагрузки активный модуль боя сам повторно планирует удар.
          await DW_API.tabsReload(tabId);
        } else {
          await DW_API.tabsCreate({
            url: monitoredUrl, active: true, pinned: tab.pinned, index: tab.index
          });
          await DW_API.tabsRemove(tabId);
        }
      } else if (state.global.useReloader || new URL(monitoredUrl).searchParams.has('UIN')) {
        await DW_API.tabsReload(tabId);
      }
    } catch (_) {
      // Вкладка могла быть закрыта пользователем или адрес уже изменился.
    } finally {
      monitoredTabs.delete(tabId);
    }
  }, STUCK_TIMEOUT);
  monitoredTabs.set(tabId, { timer, targetUrl });
}

async function injectForPage(url, tabId) {
  const current = new URL(url);
  const path = current.pathname;
  const colosseumPages = ['/battle_group.php', '/colosseum.php', '/world/colosseum.php'];
  if (!state.global.run && !(state.battleAI?.learnColosseum && colosseumPages.includes(path))) return;
  let files = [];
  switch (path) {
    case '/inventory.php':
      files = [FILES.inventory];
      break;
    case '/points.php':
      if (state.totems.run) files = [FILES.totems];
      break;
    case '/parcels.php':
      files = [FILES.parcels];
      break;
    case '/world/dungeon.php':
    case '/world/world.php':
      files = [FILES.captcha, state.world.slave ? FILES.worldSlave : FILES.world, FILES.smartWorld];
      break;
    case '/world/resource.php':
      if (state.extract.run) {
        files = [FILES.extract];
        if (String(state.extract.type) === '2') files.push(FILES.captcha);
      }
      break;
    case '/battle_group.php':
      if (state.battleAI?.learnColosseum || state.battles.run) files.push(FILES.battleAI);
      if (state.battles.run) files.push(FILES.battles);
      break;
    case '/colosseum.php':
    case '/world/colosseum.php':
      if (state.battleAI?.learnColosseum) files = [FILES.battleAI];
      break;
    case '/world/castle.php':
      if (Number(state.castle.action) && !current.searchParams.has('all')) files = [FILES.castle];
      break;
    case '/craft.php':
      if (state.workshop.run) files = [FILES.craft];
      break;
    case '/battleground.php':
    case '/world/world_bg.php':
      if (state.battlefield.run) files = [FILES.battlefieldDate, FILES.battlefield];
      break;
    case '/index.php':
      files = [FILES.mainPage];
      break;
    case '/user.php':
      files = [FILES.user];
      break;
    case '/forge.php':
      break;
    case '/class.php':
      break;
    case '/buff.php':
      break;
    case '/leader.php':
      break;
    default:
  }
  if (files.length) {
    await DW_API.scriptingExecute({ target: { tabId }, files });
  }
}

chrome.webNavigation.onCompleted.addListener(async ({ tabId, frameId, url }) => {
  if (frameId !== 0 || !isGameUrl(url)) return;
  await ensureStateReady();
  stopMonitoring(tabId);
  if (!state.global.run && !state.battleAI?.learnColosseum) return;
  try {
    await injectForPage(url, tabId);
  } catch (error) {
    if (state.global.debug) showMessage({ warn: true, text: error.message });
  }
});

chrome.webNavigation.onBeforeNavigate.addListener(async ({ tabId, frameId, url }) => {
  if (frameId !== 0 || !isGameUrl(url)) return;
  readyTabs.delete(tabId);
  await ensureStateReady();
  if (state.global.run || state.global.useReloader) startMonitoring(tabId, url);
  else stopMonitoring(tabId);
});
chrome.webNavigation.onErrorOccurred.addListener(({ frameId, tabId }) => {
  if (frameId !== 0) return;
  readyTabs.delete(tabId);
  stopMonitoring(tabId);
});
chrome.tabs.onRemoved.addListener((tabId) => {
  readyTabs.delete(tabId);
  stopMonitoring(tabId);
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') readyTabs.delete(tabId);
});
chrome.storage.onChanged.addListener((changes) => {
  for (const [key, { newValue }] of Object.entries(changes)) state[key] = newValue;
});
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== SLEEP_ALARM) return;
  await ensureStateReady();
  await setState({ global: { ...state.global, sleep: null, run: false } });
});
chrome.runtime.onStartup.addListener(() => {
  ensureStateReady().then(async () => {
    await scheduleSleep(state.global.sleep);
    if (state.update?.metadataUrl) await checkForUpdates();
  }).catch(() => {});
});
chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  if (reason === 'install') await resetState();
  else {
    const saved = await DW_API.storageGet(null);
    const migrated = mergeDefaults(initialState, sanitizeState(saved));
    await DW_API.storageClear();
    await DW_API.storageSet(migrated);
    for (const key of Object.keys(state)) delete state[key];
    Object.assign(state, migrated);
  }
  await loadDynamicValues(true);
  if (state.update?.metadataUrl) await checkForUpdates();
});

async function loadDynamicValues(isInstallOrUpdate = false) {
  await ensureStateReady();
  const tab = await getGameTab();
  if (!tab) {
    showMessage({
      warn: true,
      text: 'Откройте вкладку Dreamwar.ru и повторите сканирование в системных настройках.'
    });
    return;
  }
  if (isInstallOrUpdate) {
    const platform = await DW_API.runtimeGetPlatformInfo();
    await setState({ platform: { ...state.platform, isMobile: platform.os === 'android' } });
    readyTabs.delete(tab.id);
    await injectContentCore(tab.id);
  }
  if (!await waitForGameTab(tab.id)) {
    showMessage({
      warn: true,
      text: 'Страница игры ещё загружается. Автоматическое сканирование отложено.'
    });
    return;
  }
  const scanActions = ['parse-user', 'scan-folders', 'scan-skills', 'scan-scrolls', 'scan-teleports'];
  for (const action of scanActions) {
    try {
      // Каждый сканер сам выбирает подходящую открытую вкладку и её режим.
      // Отправлять весь набор в первую вкладку нельзя: там отвечал только персонаж.
      await handleScan(action);
    } catch (error) {
      if (state.global.debug) showMessage({ warn: true, text: `${action}: ${error.message}` });
    }
  }
  await setBadge();
  showMessage({
    warn: false,
    text: isInstallOrUpdate ? `призрак·dw ${chrome.runtime.getManifest().version} готов к работе` : 'Данные персонажа обновлены'
  });
}
