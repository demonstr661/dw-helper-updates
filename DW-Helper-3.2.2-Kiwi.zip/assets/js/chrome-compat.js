const DW_API = (() => {
  function call(target, method, args = []) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const resolveOnce = (value) => {
        if (settled) return;
        settled = true;
        resolve(value);
      };
      const rejectOnce = (error) => {
        if (settled) return;
        settled = true;
        reject(error instanceof Error ? error : new Error(String(error)));
      };
      const callback = (...values) => {
        const error = chrome.runtime.lastError;
        if (error) {
          rejectOnce(new Error(error.message));
          return;
        }
        resolveOnce(values.length > 1 ? values : values[0]);
      };
      try {
        const result = target[method](...args, callback);
        if (result && typeof result.then === 'function') {
          result.then(resolveOnce, rejectOnce);
        }
      } catch (error) {
        rejectOnce(error);
      }
    });
  }

  return {
    storageGet: (keys = null) => call(chrome.storage.local, 'get', [keys]),
    storageSet: (items) => call(chrome.storage.local, 'set', [items]),
    storageClear: () => call(chrome.storage.local, 'clear'),
    tabsQuery: (query) => call(chrome.tabs, 'query', [query]),
    tabsSendMessage: (tabId, message) => call(chrome.tabs, 'sendMessage', [tabId, message]),
    tabsGet: (tabId) => call(chrome.tabs, 'get', [tabId]),
    tabsReload: (tabId) => call(chrome.tabs, 'reload', [tabId]),
    tabsCreate: (properties) => call(chrome.tabs, 'create', [properties]),
    tabsRemove: (tabId) => call(chrome.tabs, 'remove', [tabId]),
    runtimeSendMessage: (message) => call(chrome.runtime, 'sendMessage', [message]),
    runtimeGetPlatformInfo: () => call(chrome.runtime, 'getPlatformInfo'),
    scriptingExecute: (options) => call(chrome.scripting, 'executeScript', [options]),
    alarmsClear: (name) => call(chrome.alarms, 'clear', [name]),
    badgeText: (options) => call(chrome.action, 'setBadgeText', [options]),
    badgeColor: (options) => call(chrome.action, 'setBadgeBackgroundColor', [options])
  };
})();
