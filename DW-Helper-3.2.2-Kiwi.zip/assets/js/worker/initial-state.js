const initialState = {
  battles: {
    attack: '1', check_enemy: true, checkThresholdHealth: false,
    enemy_delay: '120000', defence: '1', run: false, thresholdHealth: null,
    turnOffBattle: false, turnOfHealthPoints: null
  },
  battleAI: {
    mode: 'observe', autoSkills: true, learnColosseum: true,
    memory: {}, lastDecision: null, lastObservation: null
  },
  battlefield: { run: false, map: null, step: 0 },
  captcha: {
    token: '', service: null, status: 'idle', balance: null, balanceRub: null,
    currency: null, usdRate: null, updatedAt: null, error: ''
  },
  castle: {
    action: '0', attackBoss: false, checkUndergroundQuest: true,
    gainUpTo: '20', powder: 'none', parameter: 'defence'
  },
  extract: { run: false, type: 0, is_entered_code: false },
  folders: {},
  game: {
    countStoneOfBalance: 0, ignoreBugLocations: false, oldRoutes: false,
    ownGate: false, ownGateSulfur: '0', sideTowers: [], sideCastles: [],
    useStoneOfBalance: false
  },
  global: {
    captcha: 0, checkBelt: false, checkFlask: false, colorBadge: '',
    debug: false, faster: false, injectNavigations: false, isRefresh: false,
    run: false, saveLocation: false, showNotifies: true, sleep: null,
    sound: false, textBadge: '', to_url: false, useReloader: false,
    newDesign: false, withRage: false, themeColor: '#00d9a3', fontScale: '115'
  },
  inventory_actions: { moved: 0, to_folders: 0 },
  inventory_filters: { stones: 0, class: 0, sets: false, mods: false, belts: false },
  inventoryReport: {
    status: 'idle', processed: 0, total: 0, succeeded: 0, failed: 0,
    amounts: {}, items: [], startedAt: null, finishedAt: null
  },
  inventoryPreview: {
    status: 'idle', items: [], createdAt: null, error: ''
  },
  kitList: {},
  kits: {
    world: { name: 'Логова, подземки, земли', value: '0' },
    arena: { name: 'Арена', value: '0' },
    battlefield: { name: 'Поле битв', value: '0' },
    main: { name: 'По умолчанию', value: '0' }
  },
  smartWorld: {
    enabled: true, allowScroll59: false, allowBalanceStones: false,
    currentDestination: null, blockedEdges: [],
    consumableAttempts: { scroll59: false, balance: false }, lastReason: ''
  },
  move: {
    routes: [], active: 0, step: 0, location: null,
    target_location: null, recent_location: []
  },
  no_refresh: { link: null, sleepId: null },
  parcels: { send: false, fill: true, receive: false, theme: '1', text: '1' },
  platform: { isMobile: false },
  popup: { activeTab: 0, activeAccordion: 0, navigationVersion: 2, allQuests: false, showCompletedQuests: false, logs: [] },
  questStatus: {},
  quests: {
    sulfurCollection: false, helpInBattles: false, assistanceInSieges: false,
    secretMission: false, enemySupplies: false, importantSupplies: false,
    attackTheEnemy: false, defenceOfTerritories: false,
    clearingTheLaboratory: false, arenaBattle: false,
    difficultArenaBattle: false, colosseumQuest: false
  },
  scrolls: {},
  scrollSetup: {
    scrollLife: null, scrollFullLife: null, scrollMana: null,
    scrollLifeEnabled: false, scrollFullLifeEnabled: false,
    scrollManaEnabled: false,
    sorted: ['scrollLife', 'scrollFullLife', 'scrollMana']
  },
  dnd: {},
  skills: {},
  classSkills: { list: [], points: null },
  temp: {
    debug: '', last_map: { id: null, isRestart: false }, leprechauns: 0, od: 0
  },
  totems: { run: true },
  workshop: { run: true },
  world: {
    attack: false, attackAll: false, attackInClanArena: false, fullMap: false,
    highArena: false, highLair: false, infinityArena: false, map: 0,
    manyMobs: false, manyMobsCount: '7', restartFarm: false, returned: true,
    showMap: false, slave: false, actionWithoutBuffs: '1',
    useBuffScrolls: '0', useMobBuffScrolls: '0'
  },
  update: {
    metadataUrl: '', latestVersion: null, downloadUrl: '', notes: '',
    status: 'idle', error: '', lastCheckedAt: null
  },
  user: {
    buffsTime: null, mobsBuffsTime: null, city: null, clan_id: null,
    is_hero: false, lvl: null, od: null, os: null, side: null,
    nick: null, name: null, color: null
  },
  informer: { clearingDungeons: null, catchLeprechauns: null }
};
