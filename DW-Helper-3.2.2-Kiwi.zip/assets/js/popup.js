let state = {};
let activeSection = 0;
let busyCount = 0;
let captchaConnectTimer = null;

const DEFAULT_THEME_COLOR = '#00d9a3';
const CAPTCHA_REFRESH_INTERVAL = 60_000;
const root = document.getElementById('popup');
const navigation = document.getElementById('navigation');
const groupsRoot = document.getElementById('groups');
const busyIndicator = document.getElementById('busy');

const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5.5 9.5V21h13V9.5M9 21v-7h6v7"/>',
  bag: '<path d="M5 8h14l-1 13H6L5 8Z"/><path d="M9 9V6a3 3 0 0 1 6 0v3"/>',
  world: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/>',
  route: '<circle cx="6" cy="18" r="2"/><circle cx="18" cy="6" r="2"/><path d="M8 18h3a3 3 0 0 0 0-6h2a3 3 0 0 0 3-3V8"/>',
  bookmark: '<path d="M6 3h12v18l-6-4-6 4V3Z"/><path d="M9 8h6"/>',
  bolt: '<path d="m13 2-8 12h7l-1 8 8-12h-7l1-8Z"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>'
};

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
  })[char]);
}

function icon(name) {
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.info}</svg>`;
}

function normalizeThemeColor(value) {
  const color = String(value || '');
  return /^#[\da-f]{6}$/i.test(color) ? color.toLowerCase() : DEFAULT_THEME_COLOR;
}

function colorChannels(color) {
  return [1, 3, 5].map((start) => parseInt(color.slice(start, start + 2), 16));
}

function relativeLuminance(channels) {
  const linear = channels.map((channel) => {
    const value = channel / 255;
    return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
  });
  return linear[0] * 0.2126 + linear[1] * 0.7152 + linear[2] * 0.0722;
}

function contrastRatio(first, second) {
  const light = Math.max(relativeLuminance(first), relativeLuminance(second));
  const dark = Math.min(relativeLuminance(first), relativeLuminance(second));
  return (light + 0.05) / (dark + 0.05);
}

function mixColor(channels, target, amount) {
  return `#${channels.map((channel, index) => Math.round(channel + (target[index] - channel) * amount).toString(16).padStart(2, '0')).join('')}`;
}

function applyTheme(value) {
  const color = normalizeThemeColor(value);
  const channels = colorChannels(color);
  const darkInk = [4, 19, 15];
  const lightInk = [255, 255, 255];
  const ink = contrastRatio(channels, darkInk) >= contrastRatio(channels, lightInk) ? '#04130f' : '#ffffff';
  const hover = relativeLuminance(channels) > 0.55
    ? mixColor(channels, [0, 0, 0], 0.08)
    : mixColor(channels, lightInk, 0.12);
  const style = document.documentElement.style;
  style.setProperty('--accent', color);
  style.setProperty('--accent-ink', ink);
  style.setProperty('--accent-hover', hover);
  style.setProperty('--accent-soft', `rgba(${channels.join(', ')}, .07)`);
  style.setProperty('--accent-line', `rgba(${channels.join(', ')}, .5)`);
  style.setProperty('--accent-ring', `rgba(${channels.join(', ')}, .09)`);
  style.setProperty('--accent-mode-line', `rgba(${channels.join(', ')}, .24)`);
  style.setProperty('--accent-status-ring', `rgba(${channels.join(', ')}, .1)`);
  style.setProperty('--accent-busy-track', `rgba(${channels.join(', ')}, .18)`);
}

function getPath(source, path) {
  return path.split('.').reduce((value, key) => value == null ? undefined : value[key], source);
}

function setPath(target, path, value) {
  const keys = path.split('.');
  let cursor = target;
  for (const key of keys.slice(0, -1)) {
    if (!cursor[key] || typeof cursor[key] !== 'object') cursor[key] = {};
    cursor = cursor[key];
  }
  cursor[keys.at(-1)] = value;
}

function toast(message, type = 'success') {
  const item = document.createElement('div');
  item.className = `toast toast--${type}`;
  item.textContent = message;
  document.getElementById('toasts').append(item);
  setTimeout(() => item.remove(), type === 'error' ? 4500 : 2600);
}

function setBusy(active) {
  busyCount = Math.max(0, busyCount + (active ? 1 : -1));
  busyIndicator.hidden = busyCount === 0;
}

async function sendState(patch, type = 'update', from = 'popup') {
  Object.assign(state, patch);
  syncControls();
  return DW_API.runtimeSendMessage({ action: 'set-state', type, from, payload: patch });
}

function updateControl(element) {
  const path = element.dataset.state;
  const section = path.split('.')[0];
  const next = structuredClone(state[section] || {});
  let value;
  if (element.type === 'checkbox') value = element.checked;
  else value = element.value;
  setPath(next, path.split('.').slice(1).join('.'), value);
  sendState({ [section]: next }).catch((error) => toast(error.message, 'error'));
}

function renderNavigation() {
  navigation.innerHTML = DW_UI.map((section, index) => `
    <button class="nav-item ${index === activeSection ? 'is-active' : ''}" data-section="${index}" aria-current="${index === activeSection ? 'page' : 'false'}">
      ${icon(section.icon)}<span>${escapeHtml(section.short)}</span>
    </button>
  `).join('');
}

function optionsHtml(options, current) {
  return options.map(([value, label]) => `
    <option value="${escapeHtml(value)}" ${String(value) === String(current ?? '') ? 'selected' : ''}>${escapeHtml(label)}</option>
  `).join('');
}

function controlHtml(control) {
  const current = control.path ? getPath(state, control.path) : undefined;
  if (control.type === 'toggle') {
    return `<div class="control">
      <div class="control__copy"><div class="control__label">${escapeHtml(control.label)}</div>${control.hint ? `<div class="control__hint">${escapeHtml(control.hint)}</div>` : ''}</div>
      <label class="switch"><input type="checkbox" data-state="${escapeHtml(control.path)}" ${current ? 'checked' : ''} aria-label="${escapeHtml(control.label)}"><span class="switch__track"><span></span></span></label>
    </div>`;
  }
  if (control.type === 'select') {
    return `<label class="control">
      <span class="control__copy"><span class="control__label">${escapeHtml(control.label)}</span>${control.hint && control.hint !== 'folders' ? `<span class="control__hint">${escapeHtml(control.hint)}</span>` : ''}</span>
      <select class="select" data-state="${escapeHtml(control.path)}" ${control.hint === 'folders' ? 'data-folders' : ''}>${optionsHtml(control.options, current)}</select>
    </label>`;
  }
  if (control.type === 'radio') {
    return `<div class="control ${control.options.length > 3 ? 'control--stack' : ''}">
      <div class="control__label">${escapeHtml(control.label)}</div>
      <div class="radio-set">${control.options.map(([value, label]) => `
        <label class="radio-option"><input type="radio" name="${escapeHtml(control.path)}" value="${escapeHtml(value)}" data-state="${escapeHtml(control.path)}" ${String(value) === String(current) ? 'checked' : ''}><span>${escapeHtml(label)}</span></label>
      `).join('')}</div>
    </div>`;
  }
  if (control.type === 'input') {
    return `<label class="control control--stack"><span class="control__label">${escapeHtml(control.label)}</span>
      <input class="text-input" type="${escapeHtml(control.inputType)}" data-state="${escapeHtml(control.path)}" value="${escapeHtml(current ?? '')}" placeholder="${escapeHtml(control.placeholder)}" autocomplete="off" spellcheck="false">
    </label>`;
  }
  if (control.type === 'command') {
    return `<button class="btn btn--${escapeHtml(control.tone)}" data-action="${escapeHtml(control.id)}">${escapeHtml(control.label)}</button>`;
  }
  if (control.type === 'custom') return `<div data-custom="${escapeHtml(control.kind)}"></div>`;
  return '';
}

function renderGroups(openIndex = 0) {
  const section = DW_UI[activeSection];
  document.getElementById('page-title').textContent = section.title;
  document.getElementById('page-subtitle').textContent = section.subtitle;
  groupsRoot.innerHTML = section.groups.map((item, index) => {
    const controls = [];
    let commands = [];
    const flushCommands = () => {
      if (!commands.length) return;
      controls.push(`<div class="command-grid">${commands.join('')}</div>`);
      commands = [];
    };
    for (const control of item.controls) {
      if (control.type === 'command') commands.push(controlHtml(control));
      else {
        flushCommands();
        controls.push(controlHtml(control));
      }
    }
    flushCommands();
    return `<details class="group" data-group="${index}" ${index === openIndex ? 'open' : ''}>
      <summary><span class="group__title">${escapeHtml(item.title)}</span>${item.mode ? `<span class="mode ${item.mode === 'AUTO' ? 'mode--auto' : item.mode === 'DANGER' ? 'mode--danger' : ''}">${escapeHtml(item.mode)}</span>` : ''}</summary>
      ${item.description ? `<p class="group__description">${escapeHtml(item.description)}</p>` : ''}
      <div class="group__body">${controls.join('')}</div>
    </details>`;
  }).join('');
  groupsRoot.querySelectorAll('details').forEach((details) => {
    details.addEventListener('toggle', () => {
      if (!details.open) return;
      const index = Number(details.dataset.group);
      sendState({ popup: { ...state.popup, activeTab: activeSection, activeAccordion: index } }).catch(() => {});
    });
  });
  renderDynamic();
}

function selectSection(index, openIndex = 0, persist = true) {
  activeSection = Math.max(0, Math.min(DW_UI.length - 1, Number(index) || 0));
  renderNavigation();
  renderGroups(openIndex);
  document.getElementById('content').scrollTop = 0;
  if (persist) {
    sendState({ popup: { ...state.popup, activeTab: activeSection, activeAccordion: openIndex } }).catch(() => {});
  }
}

function empty(text) {
  return `<p class="empty">${escapeHtml(text)}</p>`;
}

function renderTheme(container) {
  const color = normalizeThemeColor(state.global?.themeColor);
  container.innerHTML = `<div class="theme-setting">
    <div class="control__copy">
      <div class="control__label">Цвет темы</div>
      <div class="control__hint">Меняет кнопки, переключатели, значки и активные элементы интерфейса.</div>
    </div>
    <div class="theme-setting__controls">
      <input class="theme-color" id="theme-color" type="color" data-state="global.themeColor" data-theme-color value="${color}" aria-label="Выбрать цвет темы">
      <output class="theme-color__value" id="theme-color-value" for="theme-color">${color.toUpperCase()}</output>
      <button class="btn" type="button" data-theme-reset>По умолчанию</button>
    </div>
  </div>`;
}

function renderSleep(container) {
  if (state.global?.sleep) {
    const date = new Date(state.global.sleep);
    container.innerHTML = `<div class="sleep-active"><span>Остановка: ${escapeHtml(date.toLocaleString())}</span><button class="btn" data-sleep-cancel>Отменить</button></div>`;
    return;
  }
  container.innerHTML = `<div class="sleep-form">
    <label class="control__label">Выключить бота через, минут<input class="text-input" id="sleep-minutes" type="number" min="1" max="300" placeholder="1–300"></label>
    <span></span><button class="btn" data-sleep-set>Установить</button>
  </div>`;
}

function renderScrolls(container) {
  const scrolls = state.scrolls || {};
  if (!Object.keys(scrolls).length) {
    container.innerHTML = empty('Сначала откройте страницу свитков и выполните сканирование в разделе «Система».');
    return;
  }
  container.innerHTML = `<div class="dynamic-list">${Object.entries(scrolls).map(([key, item]) => `
    <label class="dynamic-row"><span class="dynamic-row__title">${escapeHtml(item.name || key)}</span>
      <input class="text-input" type="number" min="0" data-state="scrolls.${escapeHtml(key)}.value" value="${escapeHtml(item.value ?? 0)}" placeholder="Количество">
    </label>`).join('')}</div>`;
}

function renderKits(container) {
  const kits = state.kits || {};
  const available = state.kitList || {};
  if (!Object.keys(available).length) {
    container.innerHTML = empty('Комплекты не загружены. Откройте комплекты в игре и нажмите «Сканировать комплекты».');
    return;
  }
  container.innerHTML = `<div class="dynamic-list">${Object.entries(kits).map(([key, kit]) => `
    <label class="dynamic-row"><span class="dynamic-row__title">${escapeHtml(kit.name || key)}</span>
      <select class="select" data-state="kits.${escapeHtml(key)}.value">
        <option value="0">По умолчанию</option>
        ${Object.values(available).map((item) => `<option value="${escapeHtml(item.id)}" ${String(item.id) === String(kit.value) ? 'selected' : ''}>${escapeHtml(item.name)}</option>`).join('')}
      </select>
    </label>`).join('')}</div>`;
}

function renderSkills(container) {
  const skills = state.skills || {};
  if (!Object.keys(skills).length) {
    container.innerHTML = empty('Умения не загружены. Откройте страницу умений и выполните сканирование.');
    return;
  }
  container.innerHTML = `<div class="dynamic-list">${Object.entries(skills).map(([key, skill]) => `
    <div class="dynamic-row"><span class="dynamic-row__title">${escapeHtml(skill.name || key)}${skill.bonus ? `<span class="dynamic-row__meta">${escapeHtml(skill.bonus)}</span>` : ''}</span>
      <label class="switch"><input type="checkbox" data-state="skills.${escapeHtml(key)}.value" ${skill.value ? 'checked' : ''} aria-label="Использовать ${escapeHtml(skill.name || key)}"><span class="switch__track"><span></span></span></label>
    </div>`).join('')}</div>`;
}

function renderSkillGroups(container) {
  const skills = state.skills || {};
  if (!Object.keys(skills).length) {
    container.innerHTML = empty('Группы появятся после сканирования умений.');
    return;
  }
  const options = [['0', 'Не задано'], ['1', '1-я группа'], ['2', '2-я группа']];
  container.innerHTML = `<div class="dynamic-list">${Object.entries(skills).map(([key, skill]) => `
    <label class="dynamic-row"><span class="dynamic-row__title">${escapeHtml(skill.name || key)}</span>
      <select class="select" data-state="skills.${escapeHtml(key)}.group">${optionsHtml(options, skill.group)}</select>
    </label>`).join('')}</div>`;
}

function renderClassSkills(container) {
  const data = state.classSkills || { list: [], points: null };
  const points = data.points == null ? 'Сканирование ещё не выполнялось.' : `Свободных очков: ${data.points}`;
  const list = Array.isArray(data.list) ? data.list : [];
  container.innerHTML = `<p class="empty">${escapeHtml(points)}</p>${list.length ? `<div class="dynamic-list">${list.map((skill) => `
    <div class="dynamic-row"><span class="dynamic-row__title">${escapeHtml(skill.name)}<span class="dynamic-row__meta">Уровень: ${escapeHtml(skill.lvl)}${skill.bonus ? ` · ${escapeHtml(skill.bonus)}` : ''}</span></span>
      ${Number(data.points) > 0 ? `<span class="inline-actions"><button class="btn" data-class-points="${escapeHtml(skill.id)}_10">+10</button><button class="btn" data-class-points="${escapeHtml(skill.id)}_50">+50</button></span>` : '<span></span>'}
    </div>`).join('')}</div>` : ''}`;
}

function renderScrollSetup(container) {
  const setup = state.scrollSetup || {};
  const labels = { scrollLife: 'Здоровья', scrollFullLife: 'Полного здоровья', scrollMana: 'Маны' };
  const order = Array.isArray(setup.sorted) ? setup.sorted : Object.keys(labels);
  container.innerHTML = `<div class="scroll-order">${order.map((key, index) => `
    <div class="scroll-item"><span class="scroll-item__handle" aria-hidden="true">⠿</span>
      <span class="scroll-item__name">${escapeHtml(labels[key] || key)}</span>
      <input class="text-input" type="number" min="0" data-state="scrollSetup.${escapeHtml(key)}" value="${escapeHtml(setup[key] ?? '')}" placeholder="HP/MP" aria-label="Порог: ${escapeHtml(labels[key] || key)}">
      <span class="scroll-item__controls"><label class="switch"><input type="checkbox" data-state="scrollSetup.${escapeHtml(key)}Enabled" ${setup[`${key}Enabled`] ? 'checked' : ''} aria-label="Включить ${escapeHtml(labels[key] || key)}"><span class="switch__track"><span></span></span></label>
        <button class="icon-button" data-scroll-move="${escapeHtml(key)}:-1" ${index === 0 ? 'disabled' : ''} aria-label="Выше">↑</button><button class="icon-button" data-scroll-move="${escapeHtml(key)}:1" ${index === order.length - 1 ? 'disabled' : ''} aria-label="Ниже">↓</button></span>
    </div>`).join('')}</div>`;
}

function renderCaptcha(container) {
  const captcha = state.captcha || {};
  const serviceNames = {
    capMonster: 'CapMonster Cloud',
    ruCaptcha: 'ruCaptcha',
    antiCaptcha: 'Anti-Captcha'
  };
  if (!container.querySelector('[data-captcha-token]')) {
    container.innerHTML = `<div class="captcha-panel">
      <label class="control control--stack">
        <span class="control__label">Единый токен</span>
        <input class="text-input" type="password" data-captcha-token placeholder="Вставьте токен любого поддерживаемого сервиса" autocomplete="off" autocapitalize="none" spellcheck="false">
      </label>
      <div class="captcha-status" data-captcha-status role="status" aria-live="polite">
        <span class="captcha-status__dot" aria-hidden="true"></span>
        <div class="captcha-status__content">
          <div class="captcha-status__title" data-captcha-title></div>
          <div class="captcha-status__details" data-captcha-details></div>
        </div>
        <div class="captcha-balance" data-captcha-balance hidden>
          <span>Баланс</span>
          <strong data-captcha-amount></strong>
          <small data-captcha-converted></small>
        </div>
      </div>
      <p class="captcha-note">После вставки токен автоматически проверяется в CapMonster Cloud, ruCaptcha и Anti-Captcha. Решатель включается при успешной проверке. Токен хранится только локально.</p>
    </div>`;
  }

  const input = container.querySelector('[data-captcha-token]');
  if (document.activeElement !== input) input.value = captcha.token || '';
  const status = captcha.status || 'idle';
  const statusElement = container.querySelector('[data-captcha-status]');
  statusElement.className = `captcha-status captcha-status--${status}`;
  statusElement.dataset.status = status;

  let title = 'Ожидает токен';
  let details = 'Вставьте токен — подключение начнётся автоматически.';
  if (status === 'checking') {
    title = 'Проверяем токен…';
    details = 'Определяем сервис и запрашиваем баланс.';
  } else if (status === 'ready') {
    title = `${serviceNames[captcha.service] || 'Сервис капчи'} подключён`;
    details = captcha.updatedAt
      ? `Баланс обновлён в ${new Date(captcha.updatedAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}`
      : 'Решатель включён. Обновляем баланс…';
  } else if (status === 'error') {
    title = 'Капча не подключена';
    details = captcha.error || 'Проверьте токен и доступность сервиса.';
  }
  container.querySelector('[data-captcha-title]').textContent = title;
  container.querySelector('[data-captcha-details]').textContent = details;

  const balanceElement = container.querySelector('[data-captcha-balance]');
  const hasBalance = status === 'ready' && Number.isFinite(captcha.balance);
  balanceElement.hidden = !hasBalance;
  if (!hasBalance) return;

  const format = (value) => new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 4 }).format(value);
  const isRub = captcha.currency === 'RUB';
  container.querySelector('[data-captcha-amount]').textContent = isRub
    ? `${format(captcha.balance)} ₽`
    : `$${format(captcha.balance)}`;
  const converted = container.querySelector('[data-captcha-converted]');
  converted.textContent = !isRub && Number.isFinite(captcha.balanceRub)
    ? `≈ ${format(captcha.balanceRub)} ₽`
    : '';
  converted.hidden = isRub || !Number.isFinite(captcha.balanceRub);

  const balanceLevel = !Number.isFinite(captcha.balanceRub)
    ? 'unknown'
    : captcha.balanceRub < 50 ? 'low' : 'sufficient';
  balanceElement.className = `captcha-balance captcha-balance--${balanceLevel}`;
  balanceElement.dataset.level = balanceLevel;
  balanceElement.title = balanceLevel === 'unknown'
    ? 'Не удалось получить курс ЦБ для сравнения с 50 ₽'
    : balanceLevel === 'low' ? 'Баланс ниже 50 ₽' : 'Баланс от 50 ₽';
  if (captcha.error) {
    container.querySelector('[data-captcha-details]').textContent = captcha.error;
  }
}

const EXPORT_SECTIONS = [
  'battles', 'battlefield', 'battleAI', 'castle', 'extract', 'game', 'global',
  'inventory_actions', 'inventory_filters', 'kits', 'parcels', 'scrollSetup',
  'skills', 'classSkills', 'kitList', 'folders', 'scrolls', 'quests', 'questStatus',
  'world', 'workshop', 'totems', 'smartWorld'
];

function renderUpdate(container) {
  const update = state.update || {};
  const statusText = {
    idle: 'Проверка ещё не выполнялась', checking: 'Проверяем метаданные…',
    current: 'Установлена актуальная версия', available: `Доступна версия ${update.latestVersion || ''}`,
    error: 'Не удалось проверить обновление'
  }[update.status] || 'Проверка ещё не выполнялась';
  container.innerHTML = `<div class="update-panel">
    <label class="control control--stack"><span class="control__label">Официальный metadata URL</span>
      <input class="text-input" type="url" data-state="update.metadataUrl" value="${escapeHtml(update.metadataUrl || '')}" placeholder="https://…/update.json" autocomplete="off" spellcheck="false">
    </label>
    <div class="update-status update-status--${escapeHtml(update.status || 'idle')}"><strong>${escapeHtml(statusText)}</strong>
      ${update.lastCheckedAt ? `<small>Проверено: ${new Date(update.lastCheckedAt).toLocaleString('ru-RU')}</small>` : ''}
      ${update.error ? `<small>${escapeHtml(update.error)}</small>` : ''}
      ${update.notes ? `<p>${escapeHtml(update.notes)}</p>` : ''}
    </div>
    <div class="command-grid"><button class="btn" data-action="check-update">Проверить обновление</button>
      ${update.status === 'available' && update.downloadUrl ? '<button class="btn btn--primary" data-action="open-update">Открыть загрузку</button>' : ''}</div>
    <p class="empty">ZIP не заменяет файлы сам. После скачивания установите новую версию вручную; настройки можно экспортировать заранее и импортировать после.</p>
    <div class="command-grid"><button class="btn" data-export-settings>Экспорт настроек</button><button class="btn" data-import-settings>Импорт настроек</button></div>
    <input type="file" accept="application/json,.json" data-settings-file hidden>
    <p class="captcha-note">В экспорт не попадают токен капчи, игровые ссылки, UIN, pass, sid, маршруты с авторизацией и журналы.</p>
  </div>`;
}

const NON_PORTABLE_KEYS = new Set([
  '__proto__', 'prototype', 'constructor', 'captcha', 'token', 'clientkey',
  'password', 'uin', 'pass', 'sid', 'logs', 'routes', 'move', 'no_refresh',
  'currentdestination', 'authorizedurl', 'authorizedurls'
]);

function safePortableValue(value) {
  if (Array.isArray(value)) return value.map(safePortableValue);
  if (value && typeof value === 'object') {
    const result = {};
    for (const [key, item] of Object.entries(value)) {
      if (NON_PORTABLE_KEYS.has(key.toLowerCase())) continue;
      result[key] = safePortableValue(item);
    }
    return result;
  }
  if (typeof value === 'string' && /[?&](?:uin|pass|sid)=/i.test(value)) return '';
  return value;
}

function exportSettings() {
  const payload = { format: 'dw-helper-settings', version: 1, exportedAt: new Date().toISOString(), data: {} };
  for (const key of EXPORT_SECTIONS) {
    if (state[key] && typeof state[key] === 'object') payload.data[key] = safePortableValue(state[key]);
  }
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `dw-helper-settings-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast('Настройки экспортированы без токенов и игровых доступов');
}

function safeImportValue(value) {
  return safePortableValue(value);
}

async function importSettings(file) {
  if (!file) return;
  try {
    if (file.size > 2_000_000) throw new Error('Файл настроек слишком большой');
    const parsed = JSON.parse(await file.text());
    if (parsed?.format !== 'dw-helper-settings' || parsed.version !== 1 || !parsed.data || typeof parsed.data !== 'object') {
      throw new Error('Это не файл настроек призрак·dw');
    }
    const patch = {};
    for (const key of EXPORT_SECTIONS) {
      if (parsed.data[key] && typeof parsed.data[key] === 'object') patch[key] = safeImportValue(parsed.data[key]);
    }
    if (!Object.keys(patch).length) throw new Error('В файле нет поддерживаемых настроек');
    await sendState(patch);
    await refreshState();
    toast('Настройки импортированы. Токен капчи и текущие доступы не изменены.');
  } catch (error) {
    toast(error.message || 'Не удалось импортировать настройки', 'error');
  }
}

function renderBattleAI(container) {
  const ai = state.battleAI || {};
  const opponents = Object.keys(ai.memory || {}).length;
  const decision = ai.lastDecision;
  const observation = ai.lastObservation;
  const attackLabels = { '1': 'голова', '2': 'грудь', '3': 'пах', '4': 'ноги' };
  const defenceLabels = { '1': 'голова + грудь', '2': 'грудь + пах', '3': 'пах + ноги', '4': 'голова + ноги' };
  container.innerHTML = `<div class="battle-ai-panel">
    <div class="battle-ai-stats"><span>Бойцов в памяти: <strong>${opponents}</strong></span><span>Данные только локально</span></div>
    ${observation ? `<div class="battle-ai-decision"><strong>Наблюдение Колизея: +${Number(observation.samples) || 0}</strong><span>${escapeHtml((observation.fighters || []).join(', ') || 'Бойцы')}</span><small>Повторные события не учитываются повторно.</small></div>` : ai.learnColosseum ? '<p class="empty">Откройте просмотр боя Колизея: действия каждого найденного бойца будут сохранены без управления боем.</p>' : ''}
    ${decision ? `<div class="battle-ai-decision"><strong>${escapeHtml(decision.opponent || 'Противник')}</strong>
      <span>Атака: ${escapeHtml(attackLabels[decision.attack] || decision.attack || 'базовая')} · Защита: ${escapeHtml(defenceLabels[decision.defence] || decision.defence || 'базовая')}</span>
      <small>${escapeHtml(decision.reason || '')}${decision.skillIds?.length ? ` Умения: ${decision.skillIds.map(escapeHtml).join(', ')}.` : ''}</small>
    </div>` : '<p class="empty">Память появится после ходов с активным боевым модулем. В режиме подсказок решение только показывается здесь.</p>'}
  </div>`;
}

function renderSmartWorld(container) {
  const smart = state.smartWorld || {};
  const blocked = Array.isArray(smart.blockedEdges) ? smart.blockedEdges : [];
  const destination = smart.currentDestination ? `Цель: клетка ${smart.currentDestination}` : 'Маршрут будет сохранён при следующем построении.';
  container.innerHTML = `<div class="smart-world-panel">
    <div class="smart-world-stats"><span>Исключено связей: <strong>${blocked.length}</strong></span><span>${escapeHtml(destination)}</span></div>
    <p class="empty">Сначала помощник ищет обход. Свиток и камни используются только при включённом разрешении и лишь когда путей не осталось. Покупки не выполняются.</p>
    ${smart.lastReason ? `<p class="smart-world-reason">${escapeHtml(smart.lastReason)}</p>` : ''}
  </div>`;
}

const QUEST_LABELS = {
  sulfurCollection: 'Сбор серы', helpInBattles: 'Помощь в сражении',
  assistanceInSieges: 'Помощь в осадах', secretMission: 'Тайное задание',
  enemySupplies: 'Вражеские припасы', importantSupplies: 'Важные припасы',
  attackTheEnemy: 'Атаковать врага', defenceOfTerritories: 'Защита территорий',
  clearingTheLaboratory: 'Зачистка лаборатории', arenaBattle: 'Битва на Арене',
  difficultArenaBattle: 'Сложная битва на Арене', colosseumQuest: 'Задание Колизея'
};

function questCompletedToday(entry) {
  if (entry?.status !== 'completed') return false;
  const timestamp = Date.parse(entry.updatedAt || '');
  if (!Number.isFinite(timestamp)) return false;
  const completedAt = new Date(timestamp);
  const now = new Date();
  return completedAt.getFullYear() === now.getFullYear()
    && completedAt.getMonth() === now.getMonth()
    && completedAt.getDate() === now.getDate();
}

function renderQuests(container) {
  const statuses = state.questStatus || {};
  const showCompleted = Boolean(state.popup?.showCompletedQuests);
  const statusLabels = { available: 'Доступно', active: 'В процессе', ready: 'Можно сдать', completed: 'Выполнено', unknown: 'Не проверено' };
  const rows = Object.entries(QUEST_LABELS).filter(([key]) => showCompleted || !questCompletedToday(statuses[key]));
  container.innerHTML = `<div class="quest-list">
    <div class="control"><div class="control__copy"><div class="control__label">Выбрать все доступные</div><div class="control__hint">Выполненные сегодня не выбираются</div></div><label class="switch"><input type="checkbox" data-state="popup.allQuests" ${state.popup?.allQuests ? 'checked' : ''} aria-label="Выбрать все доступные квесты"><span class="switch__track"><span></span></span></label></div>
    <div class="control"><div class="control__copy"><div class="control__label">Показать выполненные</div></div><label class="switch"><input type="checkbox" data-state="popup.showCompletedQuests" ${showCompleted ? 'checked' : ''} aria-label="Показать выполненные квесты"><span class="switch__track"><span></span></span></label></div>
    ${rows.length ? rows.map(([key, label]) => {
      const status = statuses[key]?.status || 'unknown';
      const completed = questCompletedToday(statuses[key]);
      return `<div class="quest-row ${completed ? 'is-completed' : ''}">
        <span class="quest-row__name">${escapeHtml(label)}</span>
        <span class="quest-status quest-status--${escapeHtml(status)}">${escapeHtml(statusLabels[status])}</span>
        <label class="switch"><input type="checkbox" data-state="quests.${escapeHtml(key)}" ${state.quests?.[key] && !completed ? 'checked' : ''} ${completed ? 'disabled' : ''} aria-label="${escapeHtml(label)}"><span class="switch__track"><span></span></span></label>
      </div>`;
    }).join('') : '<p class="quest-empty">Все выполненные сегодня задания скрыты. Включите «Показать выполненные», чтобы увидеть их.</p>'}
  </div>`;
}

function applyFontScale(value) {
  const allowed = ['100', '115', '130', '145'];
  const scale = allowed.includes(String(value)) ? String(value) : '115';
  document.documentElement.style.setProperty('--font-scale', String(Number(scale) / 100));
}

function formatSaleAmounts(amounts) {
  const entries = Object.entries(amounts || {}).filter(([, value]) => Number.isFinite(Number(value)));
  if (!entries.length) return 'Сумма не указана в ответе';
  return entries.map(([currency, value]) => `${new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 }).format(Number(value))} ${currency}`).join(' · ');
}

function renderSalePreview(container) {
  const preview = state.inventoryPreview || {};
  const items = Array.isArray(preview.items) ? preview.items : [];
  const ready = preview.status === 'ready' && items.length > 0;
  const status = ready ? `К продаже: ${items.length}` : preview.status === 'empty' ? 'Подходящих вещей не найдено' : 'Список ещё не сформирован';
  container.innerHTML = `<div class="sales-panel sale-preview">
    <div class="sales-status"><span>${escapeHtml(status)}</span><span>Только чтение → подтверждение</span></div>
    ${items.length ? `<div class="sales-items">${items.map((item, index) => `<div class="sale-item sale-preview__item">
      <span class="sale-item__dot" aria-hidden="true"></span><div><strong>${escapeHtml(item.name)}</strong><small>Позиция ${index + 1}</small></div>
    </div>`).join('')}</div>` : '<p class="empty">Откройте инвентарь с нужным фильтром и нажмите «Показать вещи». Никакие ссылки и игровые доступы в список не сохраняются.</p>'}
    ${preview.error ? `<p class="sale-preview__error">${escapeHtml(preview.error)}</p>` : ''}
    <button class="btn btn--primary" data-action="preview-sale">Показать вещи</button>
    <button class="btn" data-action="confirm-sale" ${ready ? '' : 'disabled'}>Подтвердить продажу</button>
    ${items.length ? '<button class="btn" data-action="cancel-sale-preview">Очистить список</button>' : ''}
  </div>`;
}

function renderSales(container) {
  const report = state.inventoryReport || {};
  const total = Number(report.total) || 0;
  const processed = Number(report.processed) || 0;
  const percent = total ? Math.min(100, Math.round(processed / total * 100)) : 0;
  const status = report.status === 'running' ? 'Продажа выполняется' : report.status === 'done' ? 'Продажа завершена' : 'Продаж ещё не было';
  const items = Array.isArray(report.items) ? report.items.slice().reverse() : [];
  container.innerHTML = `<div class="sales-panel">
    <div class="sales-summary">
      <div><span>Обработано</span><strong>${processed} / ${total}</strong></div>
      <div><span>Подтверждено</span><strong class="sales-success">${Number(report.succeeded) || 0}</strong></div>
      <div><span>Ошибки</span><strong class="sales-failed">${Number(report.failed) || 0}</strong></div>
    </div>
    <div class="sales-status"><span>${status}</span><span>${percent}%</span></div>
    <div class="sales-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent}"><span style="width:${percent}%"></span></div>
    <div class="sales-total"><span>Общая сумма</span><strong>${escapeHtml(formatSaleAmounts(report.amounts))}</strong></div>
    ${items.length ? `<div class="sales-items">${items.map(item => `<div class="sale-item ${item.confirmed ? 'is-confirmed' : 'is-failed'}">
      <span class="sale-item__dot" aria-hidden="true"></span><div><strong>${escapeHtml(item.name)}</strong><small>${item.confirmed ? escapeHtml(formatSaleAmounts(item.amounts)) : 'Подтверждение продажи не получено'}</small></div>
    </div>`).join('')}</div>` : '<p class="empty">Здесь появятся название вещи, результат и сумма каждой продажи.</p>'}
    <button class="btn" data-action="clear-sales">Очистить отчёт</button>
  </div>`;
}

function renderLogs(container) {
  const logs = Array.isArray(state.popup?.logs) ? state.popup.logs : [];
  container.innerHTML = logs.length ? `<div class="logs">${logs.slice().reverse().map((entry) => `
    <div class="log-entry"><span class="log-entry__text">${escapeHtml(entry)}</span></div>`).join('')}</div>` : empty('Событий пока нет. Здесь появятся действия модулей и ошибки выполнения.');
}

function renderLegend(container) {
  const rows = [
    ['AUTO', 'Модуль выполняет настроенные игровые действия автоматически после запуска.'],
    ['SEMI-AUTO', 'Помощник выполняет вспомогательный шаг; контроль остаётся у игрока.'],
    ['MANUAL', 'Команда запускается только явным нажатием кнопки.'],
    ['OFFLINE', 'Сканер читает только открытую страницу без сети и сохраняет данные локально.'],
    ['BETA', 'Функция находится в разработке и может требовать ручной проверки.']
  ];
  container.innerHTML = `<div class="legend">${rows.map(([name, text]) => `<div class="legend__row"><span class="mode ${name === 'AUTO' ? 'mode--auto' : ''}">${name}</span><span>${text}</span></div>`).join('')}</div>`;
}

function renderAbout(container) {
  container.innerHTML = `<div class="about">
    <p><strong>призрак·dw 3.2.0</strong> — помощник для Dreamwar.ru с новым ядром команд, адаптивным интерфейсом и настраиваемым цветом темы.</p>
    <p>Сохранены: инвентарь, кузница, посылки, Земли, готовые маршруты, бафы, квесты, боевые настройки, комплекты и сканеры.</p>
    <p>Настройки и токены находятся в локальном хранилище браузера. При обновлении конфигурация сохраняется. Для сканирования откройте соответствующую страницу игры.</p>
    <p>Перед любым автоматическим действием проверяйте выбранный маршрут и параметры. Игровые правила и ответственность за действия персонажа остаются на стороне игрока.</p>
  </div>`;
}

function renderDynamic() {
  groupsRoot.querySelectorAll('[data-custom]').forEach((container) => {
    const kind = container.dataset.custom;
    if (kind === 'theme') renderTheme(container);
    else if (kind === 'captcha') renderCaptcha(container);
    else if (kind === 'sleep') renderSleep(container);
    else if (kind === 'scrolls') renderScrolls(container);
    else if (kind === 'kits') renderKits(container);
    else if (kind === 'skills') renderSkills(container);
    else if (kind === 'skillGroups') renderSkillGroups(container);
    else if (kind === 'classSkills') renderClassSkills(container);
    else if (kind === 'scrollSetup') renderScrollSetup(container);
    else if (kind === 'salePreview') renderSalePreview(container);
    else if (kind === 'sales') renderSales(container);
    else if (kind === 'quests') renderQuests(container);
    else if (kind === 'smartWorld') renderSmartWorld(container);
    else if (kind === 'battleAI') renderBattleAI(container);
    else if (kind === 'update') renderUpdate(container);
    else if (kind === 'logs') renderLogs(container);
    else if (kind === 'legend') renderLegend(container);
    else if (kind === 'about') renderAbout(container);
  });
  renderFolderOptions();
  syncControls();
}

function renderFolderOptions() {
  const selectElement = groupsRoot.querySelector('[data-folders]');
  if (!selectElement) return;
  const current = state.inventory_actions?.to_folders ?? '0';
  selectElement.innerHTML = '<option value="0">Не задано</option>' + Object.values(state.folders || {}).map((folder) =>
    `<option value="${escapeHtml(folder.id)}" ${String(folder.id) === String(current) ? 'selected' : ''}>${escapeHtml(folder.name)}</option>`
  ).join('');
}

function syncControls() {
  applyTheme(state.global?.themeColor);
  applyFontScale(state.global?.fontScale);
  root.querySelectorAll('[data-state]').forEach((element) => {
    if (element === document.activeElement && ['text', 'number', 'password'].includes(element.type)) return;
    const value = getPath(state, element.dataset.state);
    if (element.type === 'checkbox') element.checked = Boolean(value);
    else if (element.type === 'radio') element.checked = String(element.value) === String(value);
    else if (value !== undefined) element.value = value ?? '';
  });
  const running = Boolean(state.global?.run);
  document.getElementById('status').textContent = running ? 'Бот активен' : 'Остановлен';
  document.getElementById('status-dot').classList.toggle('is-active', running);
  const user = state.user || {};
  const nick = user.nick || user.name;
  document.getElementById('character').textContent = nick ? `${nick}${user.lvl ? ` · ${user.lvl} ур.` : ''}` : 'Dreamwar.ru';
  if (/^#[\da-f]{3,8}$/i.test(user.color || '')) document.getElementById('character').style.color = user.color;
  else document.getElementById('character').style.removeProperty('color');
}

function commandSuccessMessage(action) {
  if (action === 'clear-state') return 'Настройки сброшены';
  if (action === 'clear-logs') return 'Журнал очищен';
  if (action === 'clear-sales') return 'Отчёт о продаже очищен';
  if (action === 'preview-sale') return state.inventoryPreview?.items?.length ? 'Список для проверки готов' : 'Подходящих вещей не найдено';
  if (action === 'confirm-sale') return 'Продажа подтверждённых вещей завершена';
  if (action === 'cancel-sale-preview') return 'Список продажи очищен';
  if (action === 'clear-battle-ai') return 'Память противников очищена';
  if (action === 'check-update') return 'Проверка обновления завершена';
  if (action === 'open-update') return 'Страница загрузки открыта';
  if (action === 'parse-user') {
    const user = state.user || {};
    const nick = user.nick || user.name;
    const details = [nick, user.lvl ? `${user.lvl} ур.` : null].filter(Boolean).join(' · ');
    return details ? `Персонаж: ${details}` : 'Данные персонажа обновлены';
  }
  if (action === 'scan-folders') {
    return `Рюкзак просканирован: папок — ${Object.keys(state.folders || {}).length}`;
  }
  return 'Действие успешно выполнено';
}

function throwCommandError(response) {
  if (response?.__dwHelperError) {
    throw new Error(String(response.message || 'Ошибка выполнения команды'));
  }
}

async function runCommand(action, button) {
  if (action === 'clear-state' && !window.confirm('Сбросить все настройки и локальные сканированные данные?')) return;
  button.disabled = true;
  setBusy(true);
  try {
    const response = await DW_API.runtimeSendMessage({ action });
    throwCommandError(response);
    if (!response) throw new Error(action === 'confirm-sale'
      ? 'Продажа не начата. Обновите предпросмотр: выборка изменилась или страница недоступна.'
      : 'Команда не выполнена. Откройте нужную страницу Dreamwar.ru и повторите.');
    if (action === 'scan-folders') {
      const next = { ...(state.inventory_actions || {}), to_folders: '0' };
      await sendState({ inventory_actions: next });
    }
    await refreshState();
    toast(commandSuccessMessage(action));
  } catch (error) {
    toast(error.message || 'Ошибка выполнения команды', 'error');
  } finally {
    button.disabled = false;
    setBusy(false);
  }
}

async function addClassPoints(payload, button) {
  button.disabled = true;
  setBusy(true);
  try {
    const response = await DW_API.runtimeSendMessage({ action: 'add-class-points', payload });
    if (!response) throw new Error('Не удалось начислить очки');
    toast('Очки начислены');
    const refreshed = await DW_API.runtimeSendMessage({ action: 'scan-class-skills' });
    throwCommandError(refreshed);
    if (!refreshed) throw new Error('Очки начислены, но список не обновлён');
    await refreshState();
  } catch (error) {
    toast(error.message, 'error');
  } finally {
    button.disabled = false;
    setBusy(false);
  }
}

async function connectCaptcha(token, refresh = false) {
  try {
    const response = await DW_API.runtimeSendMessage({
      action: 'connect-captcha',
      payload: { token, refresh }
    });
    if (!response) throw new Error('Не удалось проверить токен. Повторите попытку.');
    await refreshState();
  } catch (error) {
    toast(error.message || 'Ошибка подключения капчи', 'error');
  }
}

function scheduleCaptchaConnection(token, immediate = false) {
  clearTimeout(captchaConnectTimer);
  const normalized = String(token || '').trim();
  if (!normalized) {
    connectCaptcha('');
    return;
  }
  if (immediate) {
    connectCaptcha(normalized);
    return;
  }
  captchaConnectTimer = setTimeout(() => connectCaptcha(normalized), 550);
}

async function refreshState() {
  state = await DW_API.runtimeSendMessage({ action: 'get-state' });
  renderDynamic();
  syncControls();
}

root.addEventListener('input', (event) => {
  if (event.target.matches('[data-captcha-token]')) {
    scheduleCaptchaConnection(event.target.value);
    return;
  }
  if (!event.target.matches('[data-theme-color]')) return;
  const color = normalizeThemeColor(event.target.value);
  applyTheme(color);
  const output = document.getElementById('theme-color-value');
  if (output) output.textContent = color.toUpperCase();
});

root.addEventListener('change', (event) => {
  if (event.target.matches('[data-settings-file]')) {
    importSettings(event.target.files?.[0]);
    event.target.value = '';
    return;
  }
  if (event.target.matches('[data-captcha-token]')) {
    const token = event.target.value.trim();
    const alreadyHandled = token
      ? state.captcha?.token === token && ['checking', 'ready'].includes(state.captcha?.status)
      : !state.captcha?.token && state.captcha?.status === 'idle';
    clearTimeout(captchaConnectTimer);
    if (!alreadyHandled) scheduleCaptchaConnection(token, true);
    return;
  }
  if (event.target.matches('[data-state]')) updateControl(event.target);
});

root.addEventListener('click', async (event) => {
  if (event.target.closest('[data-export-settings]')) { exportSettings(); return; }
  if (event.target.closest('[data-import-settings]')) {
    root.querySelector('[data-settings-file]')?.click();
    return;
  }
  const sectionButton = event.target.closest('[data-section]');
  if (sectionButton) {
    selectSection(Number(sectionButton.dataset.section));
    return;
  }
  const actionButton = event.target.closest('[data-action]');
  if (actionButton) {
    await runCommand(actionButton.dataset.action, actionButton);
    return;
  }
  if (event.target.closest('[data-sleep-set]')) {
    const minutes = Number(document.getElementById('sleep-minutes').value);
    if (!Number.isInteger(minutes) || minutes < 1 || minutes > 300) {
      toast('Укажите время от 1 до 300 минут', 'error');
      return;
    }
    const global = { ...state.global, sleep: new Date(Date.now() + minutes * 60_000).toISOString() };
    await sendState({ global }, 'sleep');
    renderDynamic();
    toast('Таймер остановки установлен');
    return;
  }
  if (event.target.closest('[data-sleep-cancel]')) {
    const global = { ...state.global, sleep: null, run: false };
    await sendState({ global }, 'cancel-sleep');
    renderDynamic();
    toast('Таймер отменён, бот остановлен');
    return;
  }
  if (event.target.closest('[data-theme-reset]')) {
    const global = { ...state.global, themeColor: DEFAULT_THEME_COLOR };
    applyTheme(DEFAULT_THEME_COLOR);
    await sendState({ global });
    renderDynamic();
    toast('Цвет темы сброшен');
    return;
  }
  const pointsButton = event.target.closest('[data-class-points]');
  if (pointsButton) {
    const [id, points] = pointsButton.dataset.classPoints.split('_');
    await addClassPoints({ id, points: Number(points) }, pointsButton);
    return;
  }
  const moveButton = event.target.closest('[data-scroll-move]');
  if (moveButton) {
    const [key, direction] = moveButton.dataset.scrollMove.split(':');
    const setup = structuredClone(state.scrollSetup);
    const order = setup.sorted;
    const from = order.indexOf(key);
    const to = from + Number(direction);
    if (from < 0 || to < 0 || to >= order.length) return;
    [order[from], order[to]] = [order[to], order[from]];
    await sendState({ scrollSetup: setup });
    renderDynamic();
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action !== 'update-state') return;
  const previousTab = state.popup?.activeTab;
  Object.assign(state, message.payload || {});
  if (message.payload?.popup?.activeTab !== undefined && message.payload.popup.activeTab !== previousTab) {
    selectSection(message.payload.popup.activeTab, message.payload.popup.activeAccordion || 0, false);
  } else {
    renderDynamic();
    syncControls();
  }
  sendResponse(true);
});

(async function init() {
  try {
    state = await DW_API.runtimeSendMessage({ action: 'get-state' });
    if (!state || !state.global) throw new Error('Ядро расширения не отвечает');
    activeSection = Number(state.popup?.activeTab) || 0;
    renderNavigation();
    renderGroups(Number(state.popup?.activeAccordion) || 0);
    syncControls();
    document.getElementById('version').textContent = `v${chrome.runtime.getManifest().version}`;
    const captcha = state.captcha || {};
    const balanceStale = !captcha.updatedAt || Date.now() - captcha.updatedAt >= CAPTCHA_REFRESH_INTERVAL;
    if (captcha.token && captcha.status !== 'checking' && balanceStale) {
      connectCaptcha(captcha.token, true);
    }
  } catch (error) {
    groupsRoot.innerHTML = empty(`Не удалось загрузить состояние: ${error.message}`);
    toast(error.message, 'error');
  }
})();
