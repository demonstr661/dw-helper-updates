const toggle = (path, label, hint = '') => ({ type: 'toggle', path, label, hint });
const select = (path, label, options, hint = '') => ({ type: 'select', path, label, options, hint });
const radio = (path, label, options) => ({ type: 'radio', path, label, options });
const input = (path, label, inputType = 'text', placeholder = '') => ({
  type: 'input', path, label, inputType, placeholder
});
const command = (id, label, tone = 'secondary') => ({ type: 'command', id, label, tone });
const custom = (kind, label = '') => ({ type: 'custom', kind, label });
const group = (title, controls, mode = '', description = '') => ({
  title, controls, mode, description
});

const DW_UI = [
  {
    id: 'overview', title: 'Обзор', short: 'Главная', icon: 'home',
    subtitle: 'Запуск, уведомления и основные игровые правила',
    groups: [
      group('Рабочий режим', [
        toggle('global.run', 'Включить бота', 'Главный выключатель всех автоматических модулей'),
        toggle('global.sound', 'Звук уведомлений'),
        toggle('global.showNotifies', 'Показывать уведомления'),
        toggle('global.newDesign', 'Новый дизайн игры', 'Использовать разметку обновлённого интерфейса Dreamwar'),
        toggle('global.faster', 'Ускорять продажи и Земли', 'Пакетная продажа и меньшие технические паузы в маршрутах'),
        toggle('global.useReloader', 'Обновлять зависшие страницы', 'После тайм-аута перезагружает страницу; в активном бою повторяет удар модулем боя'),
        toggle('global.saveLocation', 'Сохранять текущую локацию'),
        custom('sleep')
      ], 'AUTO'),
      group('Логова, арены и замки', [
        toggle('world.highArena', 'Сложный уровень арены'),
        toggle('world.infinityArena', 'Арена до поражения'),
        toggle('world.attackInClanArena', 'Атаковать на клановой арене'),
        toggle('world.highLair', 'Сложный уровень логова'),
        toggle('world.fullMap', 'Полная карта логова'),
        toggle('world.slave', 'Режим ведомого'),
        toggle('castle.attackBoss', 'Атаковать боссов'),
        toggle('world.manyMobs', 'Только крупные пачки монстров'),
        select('world.manyMobsCount', 'Минимум монстров в пачке', [
          ['3', 'от 3'], ['4', 'от 4'], ['5', 'от 5'], ['6', 'от 6'],
          ['7', 'от 7'], ['8', 'от 8'], ['9', 'от 9'], ['10', 'от 10']
        ]),
        toggle('castle.checkUndergroundQuest', 'Сдавать квест на монстров'),
        toggle('world.restartFarm', 'Возвращаться на маршрут')
      ])
    ]
  },
  {
    id: 'inventory', title: 'Инвентарь', short: 'Инвентарь', icon: 'bag',
    subtitle: 'Фильтры, отделы рюкзака, кузница и посылки',
    groups: [
      group('Фильтры вещей', [
        radio('inventory_filters.stones', 'Камни', [['0', 'Выкл'], ['5', '5 камней'], ['6', '6 камней']]),
        select('inventory_filters.class', 'Качество / дроп', [
          ['0', 'Все'], ['1', '10%'], ['2', '20%'], ['3', '30%'], ['4', '40%'],
          ['5', '50%'], ['6', '60%'], ['7', '70%'], ['8', '80%'], ['100', 'Артефакты']
        ]),
        toggle('inventory_filters.sets', 'Только сеты'),
        toggle('inventory_filters.mods', 'Модификаторы и скрижали'),
        toggle('inventory_filters.belts', 'Показывать пояса', 'Параметр фильтра определяется по ссылке «Пояса» на открытой странице')
      ]),
      group('Предпросмотр продажи', [custom('salePreview')], 'MANUAL', 'Сначала проверьте список. Продажа начинается только после подтверждения неизменной выборки.'),
      group('Отчёт о продаже', [custom('sales')]),
      group('Действия с выборкой', [
        select('inventory_actions.to_folders', 'Отдел рюкзака', [['0', 'Не задано']], 'folders'),
        select('inventory_actions.moved', 'Действие', [
          ['0', 'Выкл'], ['5', 'Продать'], ['2', 'В рюкзак'], ['3', 'Из рюкзака'],
          ['1', 'В отдел'], ['4', 'Из отдела']
        ]),
        toggle('totems.run', 'Продавать тотемы'),
        toggle('workshop.run', 'Автоматическая мастерская')
      ], 'SEMI-AUTO'),
      group('Слияние и разбор', [
        select('castle.powder', 'Порошок', [
          ['none', 'Без порошка'], ['black', 'Чёрный'], ['red', 'Красный'],
          ['extra', 'Особый'], ['gold', 'Золотой'], ['mithril', 'Мифриловый'],
          ['special', 'Специальный']
        ]),
        command('merge-items', 'Запустить слияние', 'primary'),
        command('break-items', 'Разбить на камни')
      ]),
      group('Усиление и зачарование', [
        radio('castle.action', 'Режим дворца', [['0', 'Выкл'], ['1', 'Заточка'], ['2', 'Крафт']]),
        radio('castle.gainUpTo', 'Усилять до', [['10', '+10'], ['15', '+15'], ['20', '+20']]),
        command('gain-item', 'Усилить выбранную вещь', 'primary'),
        select('castle.parameter', 'Желаемый параметр (+20%)', [
          ['defence', 'Защита'], ['damage', 'Урон'], ['dodge', 'Уворот'],
          ['accuracy', 'Точность'], ['critical ', 'Крит'], ['anticritical', 'Антикрит'],
          ['power', 'Сила'], ['agility', 'Ловкость'], ['health', 'Здоровье']
        ]),
        command('grade-item', 'Зачаровать выбранную вещь', 'primary')
      ]),
      group('Посылки', [
        toggle('parcels.receive', 'Принимать'),
        toggle('parcels.fill', 'Заполнять'),
        toggle('parcels.send', 'Отправлять после подтверждения'),
        input('parcels.theme', 'Тема', 'text', 'Тема посылки'),
        input('parcels.text', 'Текст', 'text', 'Текст посылки')
      ], 'MANUAL')
    ]
  },
  {
    id: 'world', title: 'Мир', short: 'Мир', icon: 'world',
    subtitle: 'Земли, маршруты, ресурсы и поле битв',
    groups: [
      group('Земли Грёз', [
        toggle('world.showMap', 'Показывать карту'),
        toggle('world.attack', 'Автонападение'),
        toggle('world.attackAll', 'Нападать на всех'),
        toggle('world.returned', 'Возвращаться в город'),
        toggle('global.injectNavigations', 'Перемещение кнопками')
      ], 'AUTO'),
      group('Готовый маршрут', [
        select('world.map', 'Направление', [
          ['0', 'Выключено'], ['6', 'Кузня'], ['1', 'Изгои'], ['2', 'Падшие'],
          ['3', 'Драконы'], ['4', 'Тайны'], ['5', 'Все логова'], ['8', 'Логова на ОС'],
          ['7', 'Арена'], ['14', 'Клановая арена'], ['9', 'Лепреконы'],
          ['10', 'Фарм 60'], ['11', 'Фарм 65'], ['12', 'Фарм 68'], ['13', 'Фарм 75'],
          ['21', 'Замок 1472'], ['22', 'Замок 1938'], ['23', 'Замок 731'],
          ['24', 'Замок 3689'], ['25', 'Замок 4002'], ['26', 'Замок 4644'],
          ['27', 'Замок 2508'], ['28', 'Замок 304496606'], ['29', 'Замок 304497594'],
          ['32', 'Цитадель 4171'], ['33', 'Цитадель 1854'], ['34', 'Цитадель 4306'],
          ['35', 'Цитадель 8167'], ['36', 'Цитадель 30112'], ['37', 'Цитадель 32422'],
          ['38', 'Цитадель 304496185'], ['39', 'Цитадель 304497615']
        ])
      ], 'AUTO'),
      group('Умные Земли', [
        custom('smartWorld'),
        toggle('smartWorld.enabled', 'Альтернативные маршруты', 'При явном отказе перехода исключает связь и строит другой путь'),
        toggle('smartWorld.allowScroll59', 'Разрешить свиток item id 59', 'Одна попытка, только если альтернативных путей не осталось; без покупок'),
        toggle('smartWorld.allowBalanceStones', 'Разрешить камни равновесия', 'Одна попытка после свитка, только по ссылке, найденной на странице')
      ], 'AUTO'),
      group('Правила мира', [
        toggle('game.useStoneOfBalance', 'Использовать камни равновесия'),
        toggle('game.ignoreBugLocations', 'Обход проблемных локаций'),
        toggle('game.oldRoutes', 'Использовать старые маршруты'),
        select('game.ownGateSulfur', 'Ворота на Серу', [
          ['0', 'Не задано'], ['8486', 'Верхние'], ['9278', 'Средние'], ['10086', 'Нижние']
        ])
      ]),
      group('Добыча ресурсов', [
        toggle('extract.run', 'Копать ресурсы'),
        radio('extract.type', 'Режим капчи', [
          ['0', 'Выкл'], ['1', 'Без сервиса капчи'], ['2', 'Сервис капчи']
        ])
      ], 'SEMI-AUTO'),
      group('Поле битв', [
        toggle('battlefield.run', 'Активировать модуль'),
        command('create-battleground', 'Создать команду'),
        command('ready-battleground', 'Подать готовность', 'primary'),
        command('self-battleground', 'Войти одиночкой')
      ])
    ]
  },
  {
    id: 'prepare', title: 'Подготовка', short: 'Подготовка', icon: 'bookmark',
    subtitle: 'Бафы, колбы, свитки, комплекты, квесты и классовые умения',
    groups: [
      group('Бафы персонажа', [
        toggle('global.withRage', 'Вместе с яростью'),
        command('default-buffs', 'Взять простые', 'primary'),
        command('advanced-buffs', 'Взять улучшенные'),
        select('world.useMobBuffScrolls', 'Баф на монстров', [
          ['0', 'Не пить'], ['3', 'Атака против монстров I'], ['4', 'Атака против монстров II'],
          ['5', 'Атака против монстров III'], ['6', 'Атака против монстров IV'],
          ['7', 'Атака против монстров V'], ['8', 'Усиленная атака I'], ['9', 'Серебряная атака I']
        ]),
        radio('world.actionWithoutBuffs', 'Если свитки не найдены', [
          ['1', 'Выключить проверку бафов'], ['2', 'Выключить бота']
        ]),
        radio('world.useBuffScrolls', 'Проверка бафов', [
          ['0', 'Не пить'], ['1', 'Простые свитки'], ['2', 'Свитки высокого блага']
        ])
      ], 'AUTO'),
      group('Колбы и пояс', [
        toggle('global.checkFlask', 'Проверять состояние колб'),
        command('gradeon', 'Включить колбы', 'primary'),
        command('gradeoff', 'Выключить колбы'),
        toggle('global.checkBelt', 'Проверять свитки на поясе'),
        custom('scrolls')
      ]),
      group('Комплекты вещей', [custom('kits')]),
      group('Квесты', [
        custom('quests'),
        command('scan-quests', 'Обновить статусы'),
        command('take-quests', 'Взять выбранные', 'primary'),
        command('pass-quests', 'Сдать выбранные')
      ], 'MANUAL', 'Статусы читаются со страницы заданий. Выполненные сегодня скрыты и не выбираются автоматически.'),
      group('Классовые умения', [
        command('scan-class-skills', 'Сканировать классовые умения'),
        custom('classSkills')
      ])
    ]
  },
  {
    id: 'battle', title: 'Бой', short: 'Бой', icon: 'bolt',
    subtitle: 'Тактика, умения, пороги здоровья и порядок свитков',
    groups: [
      group('Тактика', [
        select('battles.attack', 'Атака', [
          ['0', 'Случайно'], ['1', 'В голову'], ['2', 'В грудь'], ['3', 'В пах'], ['4', 'В ноги']
        ]),
        select('battles.defence', 'Защита', [
          ['0', 'Случайно'], ['1', 'Голова и грудь'], ['2', 'Грудь и пах'],
          ['3', 'Пах и ноги'], ['4', 'Голова и ноги']
        ]),
        toggle('battles.run', 'Автобой'),
        toggle('battles.check_enemy', 'Тянуть бой'),
        select('battles.enemy_delay', 'Задержка между ударами', [
          ['3000', '3 секунды'], ['5000', '5 секунд'], ['10000', '10 секунд'],
          ['20000', '20 секунд'], ['30000', '30 секунд'], ['40000', '40 секунд'],
          ['50000', '50 секунд'], ['60000', '1 минута'], ['90000', '1,5 минуты'],
          ['120000', '2 минуты']
        ])
      ], 'AUTO'),
      group('Адаптивная тактика', [
        custom('battleAI'),
        select('battleAI.mode', 'Режим', [
          ['observe', 'Наблюдение — только память'],
          ['suggest', 'Подсказки — не менять форму'],
          ['auto', 'Адаптивный автобой']
        ], 'Решения выбираются из доступных зон; автобой использует существующую отправку хода'),
        toggle('battleAI.learnColosseum', 'Учиться на просмотре Колизея', 'Read-only: запоминает действия каждого бойца локально, не нажимает и не отправляет команды'),
        toggle('battleAI.autoSkills', 'Автовыбор умений в адаптивном автобое', 'Включает только умения, уже пропущенные проверками HP, MP и доступности'),
        command('clear-battle-ai', 'Очистить память противников')
      ], 'LOCAL'),
      group('Использование умений', [custom('skills')]),
      group('Группы умений', [custom('skillGroups')]),
      group('Пить свитки', [custom('scrollSetup')]),
      group('Контроль здоровья', [
        toggle('battles.checkThresholdHealth', 'Контроль низкого здоровья'),
        input('battles.thresholdHealth', 'Порог здоровья', 'number', 'Например, 30'),
        toggle('battles.turnOffBattle', 'Лечиться при преодолении порога'),
        input('battles.turnOfHealthPoints', 'Допустимая потеря HP', 'number', 'Введите значение')
      ])
    ]
  },
  {
    id: 'system', title: 'Настройки', short: 'Настройки', icon: 'settings',
    subtitle: 'Оформление, капча, сканеры, журнал и локальные данные',
    groups: [
      group('Оформление', [
        custom('theme'),
        select('global.fontScale', 'Размер шрифта', [
          ['100', '100% — компактный'], ['115', '115% — рекомендуемый'],
          ['130', '130% — крупный'], ['145', '145% — очень крупный']
        ], 'Применяется сразу ко всем разделам без изменения ширины окна')
      ], 'LOCAL', 'Цвет и размер текста сохраняются вместе с остальными настройками.'),
      group('Обновление и перенос', [custom('update')], 'LOCAL', 'Для ZIP проверяется заданный официальный metadata URL. Настройки можно перенести файлом без токена капчи и игровых доступов.'),
      group('Диагностика', [toggle('global.debug', 'Режим отладки')]),
      group('Капча', [custom('captcha')], 'AUTO', 'Один токен для CapMonster Cloud, ruCaptcha и Anti-Captcha. Сервис определяется автоматически по ответу баланса.'),
      group('Сканирование', [
        command('parse-user', 'Сканировать персонажа'),
        command('scan-folders', 'Сканировать рюкзак'),
        command('scan-skills', 'Сканировать умения'),
        command('scan-scrolls', 'Сканировать свитки'),
        command('scan-kit', 'Сканировать комплекты'),
        command('scan-teleports', 'Сканировать телепорты')
      ], 'OFFLINE', 'Без сети и автоматических переходов. Откройте нужную страницу: отделы — inventory.php?chest=1; умения — skill_learn.php?myskills=1; свитки — инвентарь; комплекты — inventory.php?wearkit=1; телепорты — список башен, замков или клан. Затем нажмите сканирование.'),
      group('Последние события', [
        custom('logs'),
        command('clear-logs', 'Очистить журнал')
      ], 'LOCAL', 'Удаляются только события журнала. Настройки и сканированные данные сохраняются.'),
      group('Обозначения', [custom('legend')]),
      group('О версии', [custom('about')]),
      group('Сброс', [command('clear-state', 'Сбросить все настройки', 'danger')], 'DANGER')
    ]
  }
];
